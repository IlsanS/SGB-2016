
INSERT INTO certification VALUES('G', 'General Audiences', 'Nothing that would offend parents for viewing by children.');
INSERT INTO certification VALUES('PG', 'Parental guidance suggested', 'Parents urged to give parental guidance.');
INSERT INTO certification VALUES('PG-13', 'Parent strongly cautioned', 'Parents are urged to be cautious. Some material may be innapropriate for pre-teen.');
INSERT INTO certification VALUES('R', 'Restricted', 'Parents are urged to be cautious. Some material may be innapropriate for pre-teen.');
INSERT INTO certification VALUES('NC-17', 'No one 17 and under admitted', 'Clearly adult. Children are not admitted.');

COMMIT;
