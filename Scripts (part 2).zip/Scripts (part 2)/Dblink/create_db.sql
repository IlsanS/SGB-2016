-- ###############################
-- # DB_LINK : CC -> CB
-- ###############################
CREATE DATABASE LINK "db_cb@renequinpolis"
CONNECT TO cb IDENTIFIED BY dummy
USING 'ORCL';

-- ###############################
-- # DB_LINK : CB -> CC
-- ###############################
CREATE DATABASE LINK "db_cc@renequinpolis"
CONNECT TO cc IDENTIFIED BY dummy
USING 'ORCL';