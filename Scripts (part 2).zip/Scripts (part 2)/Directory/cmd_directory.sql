/*
	--------------------------------------------
	-- To view all directories (Not as sys)
	--------------------------------------------
	SELECT * FROM ALL_DIRECTORIES;
		SYS	SRC_DIR	/home/oracle/bfile_dir	3
	
	--------------------------------------------
	-- To view all directories : details (Not as sys)
	--------------------------------------------
	SELECT GRANTEE, OWNER, TABLE_NAME, GRANTOR, PRIVILEGE FROM USER_TAB_PRIVS;
		CB	SYS	SRC_DIR	SYS	WRITE
		CB	SYS	SRC_DIR	SYS	READ
		PUBLIC	SYS	CB	CB	INHERIT PRIVILEGES
	
	--------------------------------------------
	-- To get the path by using the name (as sys)
	--------------------------------------------
	SELECT DIRECTORY_PATH FROM DBA_DIRECTORIES WHERE DIRECTORY_NAME='SRC_DIR';
	
		DIRECTORY_PATH                                                                 
		--------------------------------------------------------------------------------
		/home/oracle/bfile_dir     
	
	
*/