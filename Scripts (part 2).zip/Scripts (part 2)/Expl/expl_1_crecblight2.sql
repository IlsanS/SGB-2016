/*
	-- ###############################
	-- # (1) CREATECBLIGHT2
	-- ###############################
		
		* MCD -> MRD
		-------------------------------
			# Elimination des id externes (p. 49)
				• Soit entité E1 dont la clé primaire est externe ou mixte.
				• Soit entité E2 fournit identification à E1 grâce à l'association R.
				• Clé primaire de E2 est interne.
				• Alors, on importe dans E1 la clé primaire de E2. Ensuite on élimine R.
				
			# Associations many-to-many (p. 50)
				• On crée une nouvelle relation.
				• La clé primaire est la clé de E1 + la clé de E2.
				• On incorpore les attributs de R.
				• Idem pour les association N-aire avec N > 2. La clé primaire doit être réduite si c'est une super-clé.
				
		* Certification
		-------------------------------
			# id = varchar2(5) pas integer (ou number(1)??)
				(+) on a info direct sur valeur 
				(-) pê plus lent niveau comparaison entre integer et varchar 
		
			# G : General Audience
			# PG : Parental Guidance Suggested
			# PG-13 : Parents Strongly Cautioned 
			# R : Restricted 
			# NC-17 : No one 17 & under admitted 
	
*/