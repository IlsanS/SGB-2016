/*		
	-- ###############################
	-- # (2) REPLICCB
	-- ###############################
	
		* Prérequis 
		-------------------------------
			# Lancer catexp.sql ou catalog.sql
					* Creates the necessary export and import views in the data dictionary
					* Creates the EXP_FULL_DATABASE role
					* Assigns all necessary privileges to the EXP_FULL_DATABASE and IMP_FULL_DATABASE roles
					* Assigns EXP_FULL_DATABASE and IMP_FULL_DATABASE to the DBA role
					* Records the version of catexp.sql that has been installed 
				cd $ORACLE_HOME
				pwd 
					/u01/app/oracle/product/12.1.0.2/db_1
				cat $ORACLE_HOME/rdbms/admin/catalog.sql
				
			# S'assurer qu'il y a assez d'espace disque
					* estimation de la taille des tables 
						SELECT SUM(BYTES) FROM USER_SEGMENTS WHERE SEGMENT_TYPE='TABLE';
							SUM(BYTES)
							----------
							  13631488
			# Vérifier qu'on a assez de privilèges
			
	
		* Caractéristiques export
		-------------------------------
			# Mode Table
				-> Export uniquement de tables, structures et éventuellement leurs contenus

		* Cmd export
		-------------------------------
			exp PARFILE=params_exp.dat 
		
		* Caractéristiques import
		-------------------------------
			# 
			
		
		
		
		
		
		

*/