/*		
	-- ###############################
	-- # (2) ALIMCC
	-- ###############################
	
		* Prérequis (AS SYS)
		-------------------------------
			GRANT IMP_FULL_DATABASE TO CB;
			GRANT IMP_FULL_DATABASE TO CBB;
			GRANT EXP_FULL_DATABASE TO CB;
			GRANT EXP_FULL_DATABASE TO CBB;
			
			GRANT DATAPUMP_IMP_FULL_DATABASE TO CB;
			GRANT DATAPUMP_IMP_FULL_DATABASE TO CBB;
			GRANT DATAPUMP_EXP_FULL_DATABASE TO CB;
			GRANT DATAPUMP_EXP_FULL_DATABASE TO CBB;
			
		* Caractéristiques export
		-------------------------------
			# Mode Table
				-> Export uniquement de tables, structures et éventuellement leurs contenus
		
		* Caractéristiques import
		-------------------------------
			# Mode Table
				-> Import uniquement de tables, structures et éventuellement leurs contenus
				
		* Sauvegarde "incrémentale"
		-------------------------------
			# pas dispo => tout supprimer et puis tout recréer
			# 2 possibilités
				-> original exp/imp en ligne de commande 
				( + utilisation de ora_rowscn avec param QUERY
				  + "rowdependencies" lors de la création de la table
				  -> pas utilisée)
						select movie.*,ora_rowscn,scn_to_timestamp(ora_rowscn) from movie;
						select movie.*,ora_rowscn,scn_to_timestamp(ora_rowscn) time from movie where ora_rowscn>(select min(ora_rowscn) from movie);
				-> data pump expdp/impdp (meilleure)
			# TRUNCATE : supprime toutes les lignes et réinsert celles du fchier
					
		* Data pump import
		-------------------------------
			# Etapes :
				1) Disable les FK contraintes ds BDD dest
				2) Faire l'import
				3) Enable les contraintes ds BDD dst
			# TRUNCATE : supprime toutes les lignes et réinsert celles du fchier
		
		
		

*/