/*		
	
	-- ###############################
	-- # (3) ANALYSECI
	-- ###############################
	
		* Steps
		-------------------------------
			(1) Create directory
			(2) Put the file movies.txt into the directory
			(3) Create movies_ext table & mapping between movies.txt & movies_ext
			
		* Add
		-------------------------------
			(1) Add column overview 
			(2) GRANT PLUSTRACE TO cb; 
				-> to get statistic informations
			
*/