/*	
	-- ###############################
	-- # (4) CREACB 
	-- ###############################
						(contraintes)
		
		* _id
		-------------------------------
			# nombre 
				- precision -> stat
			# > 0
			# not null 
			# unique
			
		* title
		------------------------------- 
			# taille -> stat
			# not null
		
		* release_date
		-------------------------------
			# date 
			# not null
			# contrainte année (trigger)
				> 2016 non
				< 1896 (date sortie/diffusion "L'Arrivée d'un train en gare de la Ciotat" 1er film)	
			
		* status
		-------------------------------
			# varchar -> stat
				- Released
				- ... 
			# not null
			
		* vote_average
		-------------------------------
			# nombre 
				- precision -> stat
			# > 0
			
		* vote_count
		-------------------------------
			# nombre 
				- precision -> stat
			# > 0
			
		* runtime
		-------------------------------
			# nombre 
				- precision -> stat
			# > 0
			
		* certification
		-------------------------------
			# varchar2(5)
			# not null
			# valeurs
				- G : General Audience
				- PG : Parental Guidance Suggested
				- PG-13 : Parents Strongly Cautioned 
				- R : Restricted 
				- NC-17 : No one 17 & under admitted
			
		* budget
		-------------------------------
			# nombre 
				- precision -> stat
			# > 0 
			
		* tagline
		-------------------------------
			# not null -> stat
			# taille -> stat
			
		* genres.id
		-------------------------------
			# nombre 
				- precision -> stat
				- valeurs ? -> stat
			# not null
			# unique
			# > 0 
			
		* genres.name
		-------------------------------
			# not null
			# taille -> stat
			# valeurs -> stat
			
		* directors.id
		-------------------------------
			# nombre 
				- precision -> stat
				- valeurs ? -> stat
			# not null
			# unique
			# > 0 
			
		* directors.name
		-------------------------------
			# not null
			# taille -> stat
			
		* actors.id
		-------------------------------
			# nombre 
				- precision -> stat
				- valeurs ? -> stat
			# not null
			# unique
			# > 0
			
		* actors.name
		-------------------------------
			# not null
			# taille -> stat			
*/