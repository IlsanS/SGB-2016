/*		
	-- ###############################
	-- # (8) CREACC
	-- ###############################
	
		* Prérequis (AS cc)
		-------------------------------
			# create directory + grant r, w to cc 
			# user XDB unlock?
				-> User XDB existe?
					SELECT * FROM ALL_USERS;
				-> View RESOURCE_VIEW exists?
				DESCRIBE RESOURCE_VIEW
			# grant (as sys)
				-> GRANT ALTER SESSION TO CC;
				-> GRANT CREATE TYPE TO CC;
				-> GRANT CREATE TABLE TO CC;
				!!!!!For some reason its not enough 
				if those privileges are granted indirectly via roles, 
				but the privileges need to be granted directly to schema/user.
			
		* Création des xsd
		-------------------------------
			# sequence (0 -> unbounded)
				-> min défaut : 1
				-> max défaut: 1
			# nillable : false (default) 
	
	
*/