/*		
	-- ###############################
	-- # (3) ALIMCC
	-- ###############################
	
		* Prérequis ()
		-------------------------------
			# create directory + grant r, w to cb 
			
			
			
			
			
			
			
		* Fonction numériques
		-------------------------------
			# CEIL(n) : plus petit entier >= à n
			# FLOOR(n) : plus grand entier <= à n
			# ROUND(n) : arrondi
			# TRUNC(n) : "coupure" de n 
	
	
*/