	
	/* Function to generate random normal value*/
	CREATE OR REPLACE FUNCTION random_normal
	(	
		p_mean 		IN		NUMBER,
		p_stddev 	IN 		NUMBER
	)
	RETURN INTEGER
	IS
		v_result		INTEGER;
		v_random		NUMBER;
		v_add_mean		NUMBER;
		v_mult_sted		NUMBER;
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_NONE.FUNC_RANDOM_NORMAL';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_génération_nbre_aléatoire_distr_normale';
	
	BEGIN
		v_random 	:= DBMS_RANDOM.NORMAL;
		v_add_mean 	:= v_random + p_mean;
		v_mult_sted := v_add_mean * p_stddev;
		v_result 	:= TRUNC(v_mult_sted);
		
		DBMS_OUTPUT.PUT_LINE(v_mult_sted);
		DBMS_OUTPUT.PUT_LINE(v_result);
		
		RETURN v_result;
		
	EXCEPTION
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
	
	END;
