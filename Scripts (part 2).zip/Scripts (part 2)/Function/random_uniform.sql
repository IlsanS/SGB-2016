	
	/* Function to generate random uniform value*/
	CREATE OR REPLACE FUNCTION random_uniform
	(	
		p_n		IN		INTEGER
	)
	RETURN INTEGER
	IS
		v_result	INTEGER;
		v_max		NUMBER;
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_NONE.FUNC_RANDOM_UNIFORM';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_génération_nbre_aléatoire_distr_uniforme';
		
	BEGIN
		v_max := FLOOR(p_n/2);
		v_result := TRUNC(DBMS_RANDOM.VALUE(0,v_max));
		
		RETURN v_result;
		
	EXCEPTION
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
	
	END;
