A faire sur CB
------------------
	1) Créer les séquences
	2) Créer les tables 
		creaCb
		creaErrTable
		creaLogTable
		(+ movies_ext)
		+ cfr manage_transfer_clob dans le dossier Table
	3) Faire les grant 
		pour la réplication à froid (cfr expl_repliccb)
		pour http 
	4) Créer le type nomId
	5) (Re)compiler tous les packages:
		sequence 
		error 
		logging, analysis, alimcb, alimcc, genxmlfromsql
	6) Compiler la procédure (manage_constraints)
	7) Adapter si nécessaire en fonction de ton directory
	8) Alimenter certifications
	9) Exécuter fonction random_uniform
	10) Exécuter le job alimcc
	
A faire sur CBB
------------------
	1) Créer les séquences
	2) Créer les tables 
	3) Faire les grant pour la réplication à froid (cfr expl_repliccb)
	4) (Re)compiler tous les packages:
		sequence 
		error 
		logging, analysis, alimcb, alimcc
	5) Compiler la procédure (manage_constraints)
	6) Adapter si nécessaire en fonction de ton directory
	7) Alimenter certifications
	
XDB (CreaCC)
------------------
	1) Copier coller tous les xsd dans dans ton directory
	2) Faire les grant pour xdb (cfr expl_creacc)
	3) Exécuter les packages:
		sequence
		errors (spec error)
		registerxsd 
		deletexsd
	4) Enregistrer les schemas avec (register_xsd)
	5) Créer les tables (CreaCC)
	6) Ajouter toutes les contraintes (ConstraintsCC)
	
XDB (AlimCC)
------------------
	1) Créer le dblink (CC -> CB)
	2) Créer les synonyms
	3) Exécuter le package
		manageclob
	4) Créer les tables
		+ cfr manage_transfer_clob dans le dossier Table
	
XDB (ProgCC)
-------------------
	1) Exécuter function random_normal
	...