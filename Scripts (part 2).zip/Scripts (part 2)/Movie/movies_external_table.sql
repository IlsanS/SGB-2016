CREATE TABLE movies_ext 
(
	id INTEGER,
	title VARCHAR2(2000),
	release_date DATE,
	status VARCHAR2(30),
	vote_average NUMBER(3,1),
	vote_count INTEGER,
	runtime INTEGER,
	certification VARCHAR2(30),
	poster_path VARCHAR2(100),
	budget INTEGER,
	tagline VARCHAR2(2000),
	overview VARCHAR2(4000),
	genres VARCHAR2(1000),
	directors VARCHAR2(4000),
	actors VARCHAR2(4000)
)
ORGANIZATION EXTERNAL 
(
	TYPE ORACLE_LOADER
	DEFAULT DIRECTORY SRC_DIR
	ACCESS PARAMETERS 
	(
		RECORDS DELIMITED BY "\n"
		CHARACTERSET "AL32UTF8"
		STRING SIZES ARE IN characters
		FIELDS TERMINATED by X"E28199"
		MISSING FIELD VALUES ARE NULL
		(
			id UNSIGNED INTEGER EXTERNAL,
			title CHAR(2000),
			release_date CHAR(10) DATE_FORMAT DATE mask "yyyy-mm-dd",
			status CHAR(30),
			vote_average FLOAT EXTERNAL,
			vote_count UNSIGNED INTEGER EXTERNAL,
			runtime UNSIGNED INTEGER EXTERNAL,
			certification CHAR(30),
			poster_path CHAR(100),
			budget UNSIGNED INTEGER EXTERNAL,
			tagline CHAR(2000),
			overview CHAR(4000),
			genres CHAR(1000),
			directors CHAR(4000),
			actors CHAR(4000)
		)
	)
	LOCATION('movies.txt')
	
)
REJECT LIMIT UNLIMITED
;
