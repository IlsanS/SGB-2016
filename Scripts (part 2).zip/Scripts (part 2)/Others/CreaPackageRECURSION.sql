-- ###############################
-- # CREATE PACKAGE RECURSION
-- ###############################
CREATE OR REPLACE PACKAGE PACK_RECURSION 
IS 
	TYPE  T_LIST_SIMPLE_VAL IS TABLE OF VARCHAR2(150);

	-- FUNCTION calculationMean 	( p_choice	IN 	VARCHAR2(15) ) RETURN NUMERIC;
	-- FUNCTION calculationStdev	( p_choice	IN 	VARCHAR2(15) ) RETURN NUMERIC;
	-- FUNCTION calculationMedian 	( p_choice	IN 	VARCHAR2(15) ) RETURN NUMERIC;
	-- FUNCTION calculationMin		( p_choice	IN 	VARCHAR2(15) ) RETURN NUMERIC;
	-- FUNCTION calculationMax 	( p_choice	IN 	VARCHAR2(15) ) RETURN NUMERIC;
	
	FUNCTION createSelectPartStat 
	( 
		p_input			IN VARCHAR2
	) 
	RETURN VARCHAR2;
	
	FUNCTION split	
	(
		p_string		IN VARCHAR2,
		p_separator		IN VARCHAR2
	)
	RETURN T_LIST_SIMPLE_VAL;
 
END PACK_RECURSION;
/

