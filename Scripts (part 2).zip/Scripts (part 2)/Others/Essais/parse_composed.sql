WITH simple_values (id, one_value, mult_values,level,path)
AS
(
	-- Anchor member
	SELECT 
		id,
		CASE
			WHEN REGEXP_INSTR(genres,'‖') > 0 
				THEN SUBSTR(genres, 1, REGEXP_INSTR(genres,'‖') - 1)
				ELSE genres
		END AS one_value,
		SUBSTR(genres, REGEXP_INSTR(genres,'‖') + 1, LENGTH(genres) - REGEXP_INSTR(genres,'‖')) AS mult_values,
		1 AS level,
		TO_CHAR(id) AS path
	FROM   movies_ext
	
	UNION ALL
	
	--Recursive member
	SELECT 
		m.id,
		CASE
			WHEN REGEXP_INSTR(mult_values,'‖') > 0 
				THEN SUBSTR(mult_values, 1, REGEXP_INSTR(mult_values,'‖') - 1)
				ELSE mult_values
		END,
		CASE
			WHEN REGEXP_INSTR(mult_values,'‖') > 0 
				THEN SUBSTR(mult_values, REGEXP_INSTR(mult_values,'‖') + 1, LENGTH(mult_values) - REGEXP_INSTR(mult_values,'‖'))
				ELSE NULL
		END,
		level+1,
		simple_values.path || '-' || m.id AS path 
	FROM   movies_ext m
	
	INNER JOIN simple_values
	ON simple_values.id = m.id
	WHERE mult_values IS NOT NULL
)
SEARCH DEPTH FIRST BY id SET order1
CYCLE id SET cycle TO 1 DEFAULT 0

SELECT DISTINCT id, 
				one_value AS genre,
				mult_values AS genres,
				RPAD('.', (level-1)*2, '.') || id AS tree,
				level,
				path,
				cycle
				
FROM   simple_values 
ORDER BY 1