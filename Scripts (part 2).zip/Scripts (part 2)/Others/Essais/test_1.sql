CREATE OR REPLACE FUNCTION normal_function(p_id IN NUMBER) RETURN NUMBER IS
BEGIN
  RETURN p_id;
END;
/

WITH
  FUNCTION with_function(p_id IN NUMBER) RETURN NUMBER IS
  BEGIN
    RETURN p_id;
  END;
SELECT with_function(id)
FROM   t1
WHERE  rownum = 1;

WITH T(id, unGenre) 
AS 
(
	-- Anchor member.
	SELECT id, 
		CASE 
			WHEN REGEXP_INSTR(genres,'‖') > 0 
				THEN SUBSTR(genres, 1, REGEXP_INSTR(genres,'‖') - 1)
				ELSE genres
		END AS Ungenre,
		SUBSTR(genres, REGEXP_INSTR(genres,'„') + 1, LENGTH(genres) - REGEXP_INSTR(genres,'„')) AS LesAutresgenres
	FROM   movies_ext
	
	UNION ALL
	
	-- Recursive member.
	SELECT M.id,
		CASE 
			WHEN REGEXP_INSTR(LesAutresgenres,'‖') > 0 
				THEN SUBSTR(LesAutresgenres, 1, REGEXP_INSTR(LesAutresgenres,'‖') - 1)
				ELSE LesAutresgenres
		END,
		CASE 
			WHEN REGEXP_INSTR(LesAutresgenres,'‖') > 0 
				THEN SUBSTR(LesAutresgenres, REGEXP_INSTR(LesAutresgenres,'‖') + 1,LENGTH(LesAutresgenres) - REGEXP_INSTR(LesAutresgenres,'‖'))
				ELSE NULL
		END
	FROM   movies_ext M
		INNER JOIN T ON T.id = M.id
		WHERE LesAutresgenres IS NOT NULL
)	
SELECT DISTINCT id, Ungenre As genres
FROM   T
ORDER BY 1, 2