DECLARE
	l_sql     VARCHAR2(32767);
	l_cursor  SYS_REFCURSOR;
	l_value   NUMBER;
BEGIN
	l_sql := 	'WITH simple_values (id, one_value, mult_values)
				AS
				(
					SELECT 
						id,		
						CASE
							WHEN REGEXP_INSTR(genres,''‖'') > 0 
								THEN SUBSTR(genres, 1, REGEXP_INSTR(genres,''‖'') - 1)
								ELSE genres
						END AS one_value,
						SUBSTR(genres, REGEXP_INSTR(genres,''‖'') + 1, LENGTH(genres) - REGEXP_INSTR(genres,''‖'')) AS mult_values
					FROM   movies_ext
					
					UNION ALL
					
					SELECT 
						m.id,
						CASE
							WHEN REGEXP_INSTR(mult_values,''‖'') > 0 
								THEN SUBSTR(mult_values, 1, REGEXP_INSTR(mult_values,''‖'') - 1)
								ELSE mult_values
						END,
						CASE
							WHEN REGEXP_INSTR(mult_values,''‖'') > 0 
								THEN SUBSTR(mult_values, REGEXP_INSTR(mult_values,''‖'') + 1, LENGTH(mult_values) - REGEXP_INSTR(mult_values,''‖''))
								ELSE NULL
						END
					FROM   movies_ext m
						INNER JOIN simple_values
						ON simple_values.id = m.id
						WHERE mult_values IS NOT NULL
				)
				SELECT DISTINCT id, one_value As genres
				FROM   simple_values 
				ORDER BY 1, 2'
  
  OPEN l_cursor FOR l_sql;
  FETCH l_cursor INTO l_value;
  DBMS_OUTPUT.put_line('l_value=' || l_value);
  CLOSE l_cursor;
END;
/