CREATE OR REPLACE FUNCTION selectart (input IN VARCHAR2) RETURN VARCHAR2
IS
 	PRAGMA UDF;
 	v_result	VARCHAR2(300);
BEGIN
	v_result := 'MIN(' || input || ')||''/''||MAX(' || input || ')||''/''
				||AVG(' || input || ')||''/''|| MEDIAN(' || input || ')||''/''
				|| STDDEV(' || input || ')||''/''||COUNT(' || input || ')||''/''
				||COUNT(UNIQUE(certification)) AS ' || input || '';
  	RETURN v_result;
END;
/


DECLARE
  l_sql     VARCHAR2(32767);
  l_cursor  SYS_REFCURSOR;
  l_value   PACK_RECURSION.T_LIST_SIMPLE_VAL;
  genre	  VARCHAR2(100):= '18„Drama‖10756„Indie‖10769„Foreign';
BEGIN
  l_sql := 'with t as (select ''18„Drama‖10756„Indie‖10769„Foreign'' as genres from dual)
  -- end of sample data
  select REGEXP_SUBSTR (genres, ''[^‖]+'', 1, level)
  from t
  connect by level <= length(regexp_replace(genres,''[^‖]*''))+1';
  
  OPEN l_cursor FOR l_sql;
  FETCH l_cursor BULK COLLECT INTO l_value;
  
  FOR indx IN 1 .. l_value.COUNT
			
				LOOP
					DBMS_OUTPUT.put_line('l_value=' || l_value(indx));
				END LOOP;
  
  CLOSE l_cursor;
END;
/

