-- ###############################
-- # CREATE PACKAGE RECURSION
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_RECURSION 
IS

	/* DEBUT createSelectPartStat */
	FUNCTION createSelectPartStat
	( 
		p_input	IN	VARCHAR2
	)
	RETURN VARCHAR2
	IS
		v_result	VARCHAR2(300);
		-- -- Location of the error
		-- c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_RESTORE.FUNC_GETLASTDATE';
		-- -- Type of the error
		-- c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_récupération_date';
		
	BEGIN
		v_result := 'MIN(' || p_input || ')||''/''||MAX(' || p_input || ')||''/''
				|| AVG(' || p_input || ')||''/''|| MEDIAN(' || p_input || ')||''/''
				|| STDDEV(' || p_input || ')||''/''||COUNT(' || p_input || ')||''/''
				|| COUNT(UNIQUE(certification)) AS ' || p_input;
		
		RETURN v_result;
		
	-- EXCEPTION
		-- WHEN OTHERS THEN 
			-- PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_replic, c_type_err, true);
			
	END createSelectPartStat;
	/* FIN createSelectPartStat */
	
	/* DEBUT split */
	FUNCTION split
	(
		p_string		IN VARCHAR2,
		p_separator		IN VARCHAR2
	)
	RETURN T_LIST_SIMPLE_VAL
	IS
		v_sql_instr 	VARCHAR2(32767);
		v_cursor  		SYS_REFCURSOR;
		v_result   		T_LIST_SIMPLE_VAL;
		-- -- Location of the error
		-- c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_RESTORE.FUNC_GETLASTDATE';
		-- -- Type of the error
		-- c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_récupération_date';
		
	BEGIN
		v_sql_instr := 'WITH T 
						AS
						(
							SELECT '''|| p_string ||''' AS values FROM DUAL
						)
						SELECT REGEXP_SUBSTR (values, ''[^'|| p_separator ||']+'', 1, level)
						FROM T
						CONNECT BY level <= length(REGEXP_REPLACE(values,''[^'|| p_separator ||']*''))+1';
		
		OPEN v_cursor FOR v_sql_instr;
			FETCH v_cursor BULK COLLECT INTO v_result;
	  
			FOR indx IN 1 .. v_result.COUNT
				LOOP
					DBMS_OUTPUT.put_line('v_result=' || v_result(indx));
				END LOOP;
  
		CLOSE v_cursor;
		RETURN v_result;
		
	-- EXCEPTION
		-- WHEN OTHERS THEN 
			-- PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_replic, c_type_err, true);
			
	END split;
	/* FIN split */
	
END PACK_RECURSION ;
/