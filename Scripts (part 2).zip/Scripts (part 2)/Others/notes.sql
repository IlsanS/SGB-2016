---------------------------------------------
-- A Faire
---------------------------------------------
/*	-- CREATECBLIGHT2
		- création des tables (celle de createCBLight + films)
		- tailles données : prendre max celles du prof	
	
	-- REPLICCB
		- import/export					??
		- à chaud/ à froid 				??
		- à froid, quoi concerné		??
		- à chaud déjà fait				??
		- 
	
	-- ANALYSECI
		solution 1
			- create records avec tous les bons champs pour le select into
			- pr les unique prévoir un champs unique et rediriger les erreurs pour pouvoir tout mettre dans meme select
		solution 2
			- table à la volée (VM, CTE)
		récursion 
			- père : id_movie
			- fils : actors 
					 genres
					 directors

	-- CREACB
		- ajout d'un max de contraintes 
			* sans modif trucs précédents si possible
			* ajout des contr non vérif en commentaires
		- histoire des stats 99%
		- vérification cohérence des colonnes avant de les enregistrer dans la BDD
			* budget null
			* certif pas correcte 
			* genre incorrecte
			* ...
		- posters films stockés sous la forme de BLOBs (plus d'explic cfr p16 énoncé)
		
	-- ALIMCB
		 
	-- EVALFILM
	
	-- CRASHCB
			
*/