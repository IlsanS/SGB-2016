-- ###############################
-- # CREATE PACKAGE ERROR
-- ###############################
CREATE OR REPLACE PACKAGE PACK_ERROR 
IS 
	TYPE T_ERR_MSG_FORMATED IS RECORD 
	(
		f_msg			LOGGING_ERRORS.message%TYPE,
		f_location		LOGGING_ERRORS.location%TYPE,
		f_sys_msg		LOGGING_ERRORS.sys_message%TYPE,
		f_default_msg	VARCHAR2(1000)
	);
	
	ex_insert	EXCEPTION;
	c_insert	CONSTANT	NUMBER := -20001;
	PRAGMA EXCEPTION_INIT (ex_insert, -20001);
	
	ex_read		EXCEPTION;
	c_read		CONSTANT	NUMBER := -20002;
	PRAGMA EXCEPTION_INIT (ex_read, -20002);
	
	ex_update	EXCEPTION;
	c_update	CONSTANT	NUMBER := -20003;
	PRAGMA EXCEPTION_INIT (ex_update, -20003);
	
	ex_delete	EXCEPTION;
	c_delete	CONSTANT	NUMBER := -20004;
	PRAGMA EXCEPTION_INIT (ex_delete, -20004);
	
	ex_eval		EXCEPTION;
	c_eval		CONSTANT	NUMBER := -20005;
	PRAGMA EXCEPTION_INIT (ex_eval, -20005);
	
	ex_util		EXCEPTION;
	c_util		CONSTANT	NUMBER := -20006;
	PRAGMA EXCEPTION_INIT (ex_util, -20006);
	
	ex_replic	EXCEPTION;
	c_replic	CONSTANT	NUMBER := -20007;
	PRAGMA EXCEPTION_INIT (ex_replic, -20007);
	
	ex_restore	EXCEPTION;
	c_restore	CONSTANT	NUMBER := -20008;
	PRAGMA EXCEPTION_INIT (ex_restore, -20008);
	
	ex_readweb	EXCEPTION;
	c_readweb	CONSTANT	NUMBER := -20009;
	PRAGMA EXCEPTION_INIT (ex_readweb, -20009);
	
	ex_trig		EXCEPTION;
	c_trig		CONSTANT	NUMBER := -20100;
	PRAGMA EXCEPTION_INIT (ex_trig, -20100);
	
	ex_seq		EXCEPTION;
	c_seq		CONSTANT	NUMBER := -20200;
	PRAGMA EXCEPTION_INIT (ex_seq, -20200);
	
	c_inTable		CONSTANT PLS_INTEGER := 1;
	c_inFile		CONSTANT PLS_INTEGER := 2;
	c_display		CONSTANT PLS_INTEGER := 4;
	
	
	-- Log the error and raise 
	PROCEDURE report_and_stop
	(
		p_subprog		 IN 	VARCHAR2,
		p_errcode		 IN		INTEGER	:= SQLCODE,
		p_errmsg		 IN  	VARCHAR2:= NULL,
		p_append_sqlerrm IN		BOOLEAN	:= FALSE,
		p_strip_code	 IN 	BOOLEAN	:= FALSE -- If true remove ORA-... from msg
	);
	
	-- Log the error and go on
	PROCEDURE report_and_go 
	(
		p_subprog		 IN 	VARCHAR2,
		p_errcode		 IN		INTEGER	:= SQLCODE,
		p_errmsg		 IN  	VARCHAR2:= NULL,
		p_append_sqlerrm IN		BOOLEAN	:= FALSE,
		p_strip_code	 IN 	BOOLEAN	:= FALSE 
	);
	
	-- Choose where to log 
	PROCEDURE logto 
	(
		p_target IN PLS_INTEGER,
		p_dir    IN VARCHAR2 := NULL,
		p_file   IN VARCHAR2 := NULL
	);
	
	-- Check if predicate is true
	PROCEDURE assert 
	(
		p_condition       IN 	BOOLEAN,
		p_message         IN 	VARCHAR2,
		p_raise_exception IN 	BOOLEAN := TRUE,
		p_exception_name  IN 	VARCHAR2 := 'VALUE_ERROR'
	);

	
END PACK_ERROR;
/