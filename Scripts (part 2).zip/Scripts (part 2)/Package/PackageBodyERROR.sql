-- ###############################
-- # PACKAGE ERROR BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_ERROR 
IS 
	g_target	PLS_INTEGER 	:= c_inTable;
	g_file 		VARCHAR2(2000)	:= 'errors.log';
	g_dir 		VARCHAR2(2000)	:= NULL;

	-----------------------------------------
	-- PRIVATE PROCEDURES AND FUNCTIONS
	-----------------------------------------
	
	/* BEGIN log */
	PROCEDURE log
	(
		p_errcode	IN	PLS_INTEGER 		:= NULL,
		p_errmsg	IN	T_ERR_MSG_FORMATED 	:= NULL
	)
	IS 
		-- To avoid any interference between the current transaction and insert in table log_errors
		PRAGMA AUTONOMOUS_TRANSACTION;
		-- NVL(null value) : if null replace by ...
		v_sqlcode	PLS_INTEGER		:= NVL(p_errcode, SQLCODE);
		v_sqlerrm	VARCHAR2(1000)	:= NVL(p_errmsg.f_default_msg, SQLERRM);
		
	BEGIN 
	
		IF BITAND(g_target, c_inTable) = c_inTable THEN
			-- INSERT INTO log_errors(id_log, code, message, inserted_at, other_infos, localisation) 
				   -- VALUES (PACK_SEQUENCE.getIdErr, p_errcode, p_errmsg, SYSDATE, USER, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE );
			INSERT INTO logging_errors
						(
							id_log, inserted_at, username, code, location, message, sys_message, backtrace_msg
						) 
				   VALUES 
						(
							PACK_SEQUENCE.getIdErr, SYSDATE, USER, p_errcode, p_errmsg.f_location,
							p_errmsg.f_msg, p_errmsg.f_sys_msg, DBMS_UTILITY.FORMAT_ERROR_BACKTRACE 
						);
			COMMIT;
		END IF; 
		
		IF BITAND(g_target, c_inFile) = c_inFile THEN
			DECLARE
				fid   UTL_FILE.FILE_TYPE;
			BEGIN
				fid    := UTL_FILE.FOPEN(g_dir, g_file, 'A');
				UTL_FILE.PUT_LINE(	
									fid,
									'Error log by '
								    || USER
								    || ' at  '
								    || TO_CHAR(SYSDATE, 'dd/mm/yyyy HH:MI:SS')
								  );
				UTL_FILE.PUT_LINE( 
									fid, 
									p_errcode 
									|| ' - ' 
									|| NVL(p_errmsg.f_default_msg, SQLERRM) 
									|| ' : '
									|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
								  );
				UTL_FILE.NEW_LINE(fid);
				UTL_FILE.FCLOSE(fid);
			EXCEPTION
				WHEN OTHERS THEN
					UTL_FILE.FCLOSE(fid);
			END;
		END IF;
			
		IF BITAND (g_target, c_display) = c_display THEN
			DBMS_OUTPUT.PUT_LINE(   
									'Error log by '
									|| USER
									|| ' at  '
									|| TO_CHAR(SYSDATE, 'dd/mm/yyyy HH:MI:SS')
								);
			DBMS_OUTPUT.PUT_LINE(
									p_errcode 
									|| ' - ' 
									|| NVL(p_errmsg.f_default_msg, SQLERRM) 
									|| ' : '
									|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE
								);
			DBMS_OUTPUT.NEW_LINE;
		END IF;
		
	EXCEPTION
		WHEN OTHERS THEN
			DBMS_OUTPUT.PUT_LINE('PACK_ERROR.PROC_LOG : INTERNAL ERROR ! ' || SQLERRM);
			
	END log;					
	/* END log */
	
	
	/* BEGIN raise */
	PROCEDURE raise
	(
		p_errcode		IN	PLS_INTEGER 		:= NULL,
		p_errmsg		IN	T_ERR_MSG_FORMATED 	:= NULL
	)
	IS
		v_errcode	PLS_INTEGER 	:= NVL(p_errcode, SQLCODE);
		v_errmsg	VARCHAR2(1000)	:= NVL(p_errmsg.f_default_msg, SQLERRM);
		
	BEGIN
	
		-- User-defined errors
		IF v_errcode BETWEEN -20999 AND -20000 THEN
			RAISE_APPLICATION_ERROR(v_errcode, v_errmsg);
			
		-- Use positive error numbers 
		ELSIF v_errcode > 0 AND v_errcode NOT IN(1, 100) THEN
			RAISE_APPLICATION_ERROR(-20000, v_errcode || '-' || v_errmsg);
			
		-- Exception NO_DATA_FOUND
		ELSIF v_errcode IN (100, -1403) THEN
			RAISE NO_DATA_FOUND;
			
		-- Re-raise any other exception 
		ELSIF v_errcode != 0 THEN
			EXECUTE IMMEDIATE   
							'DECLARE myExc EXCEPTION; '
                           || '   PRAGMA EXCEPTION_INIT (myExc, '
                           || TO_CHAR(v_errcode)
                           || ');'
                           || 'BEGIN  RAISE myExc; END;';
		END IF;
			
	END raise;					
	/* END raise */
	
	
	/* BEGIN handle */
	PROCEDURE handle
	(
		p_errcode	IN	PLS_INTEGER 		:= NULL,
		p_errmsg	IN	T_ERR_MSG_FORMATED 	:= NULL,
		p_log		IN 	BOOLEAN 			:= TRUE,
		p_reraise	IN 	BOOLEAN 			:= FALSE
	)
	IS
	
	BEGIN
		
		IF p_log THEN
			PACK_ERROR.log(p_errcode, p_errmsg);
		END IF;
			
		IF p_reraise THEN
			PACK_ERROR.raise(p_errcode, p_errmsg);
		END IF;
		
	END handle;
	/* END handle */


	/* BEGIN format_message */
	FUNCTION format_message 
	(
		p_subprog		 IN 	VARCHAR2,
		p_errcode		 IN		INTEGER,
		p_errmsg		 IN  	VARCHAR2,
		p_append_sqlerrm IN		BOOLEAN,
		p_strip_code	 IN 	BOOLEAN
	)
	RETURN T_ERR_MSG_FORMATED 
	IS
		v_result_rec				T_ERR_MSG_FORMATED;
		v_message   				VARCHAR2 (1000);
		v_sql_errmsg				VARCHAR2 (512) 	:= SQLERRM;
		v_errmsg_cleaned 			VARCHAR2 (1000) := p_errmsg;
		v_append_sqlerrm_cleaned 	BOOLEAN 		:= p_append_sqlerrm;
		
	BEGIN
	
		-- Clean parameters
		IF p_strip_code THEN
			-- Substitute 'ORA-..' in v_sql_errmsg with ''
			OWA_PATTERN.CHANGE(v_sql_errmsg, '^ORA-\d+: ', '');
		END IF;
		
		IF p_errmsg IS NULL THEN
			v_errmsg_cleaned := v_sql_errmsg;
			v_append_sqlerrm_cleaned := FALSE;
		END IF;
		
		v_message := 'SUBPROG: '|| p_subprog || '. '
					|| 'CODE: ' || p_errcode || '. '
					|| 'MSG: ' 	|| v_errmsg_cleaned;

		IF v_append_sqlerrm_cleaned THEN
			v_message := v_message || '. SYSMSG: ' || v_sql_errmsg;
		END IF;

		-- Insert into v_result_rec
		v_result_rec.f_msg	:= 	v_errmsg_cleaned;
		v_result_rec.f_location := p_subprog;
		v_result_rec.f_sys_msg := v_sql_errmsg;	
		v_result_rec.f_default_msg := v_message;
		--INSERT INTO v_result_rec VALUES(v_errmsg_cleaned, p_subprog, v_sql_errmsg, v_message);
	
		RETURN v_result_rec;
		
   END format_message;
   /* END format_message */
   
   
   /* BEGIN find_constraint_name */
    FUNCTION find_constraint_name RETURN MY_CONSTRAINTS.CONSTRAINT_NAME%TYPE
  	IS
		-- Type vc_arr is table of varchar2(32767) index by binary_integer;
  		v_result    OWA_TEXT.VC_ARR;
  		v_found  	BOOLEAN;
		
  	BEGIN
	
  		-- Not null. check constraint with code -1400. special case.
  		IF SQLCODE = -1400 THEN
  			-- FORMAT: ("SCHEMA"."TABLE"."COLUMN") : to detect where null is
  			v_found := OWA_PATTERN.MATCH(SQLERRM, '\("(.*)"\."(.*)"\."(.*)"\)', v_result);
  			IF v_found THEN
  				RETURN v_result(2) || '_' || v_result(3) || '_nn';
  			END IF;
			
  		ELSIF SQLCODE <> 0 THEN
  			-- FORMAT: (SCHEMA.CONSTRAINT)
  			v_found := OWA_PATTERN.MATCH(SQLERRM, '\(\w+\.(.*)\)', v_result);
  			IF v_found THEN
  				RETURN v_result(1);
  			END IF;
			
  		END IF;
		
  		RETURN NULL;
		
	END find_constraint_name;
	/* END find_constraint_name */
	
	
	/* BEGIN get_constraint_message */
	FUNCTION get_constraint_message 
	(
		p_constraint_name in MY_CONSTRAINTS.CONSTRAINT_NAME%TYPE
	)
	RETURN MY_CONSTRAINTS.CONSTRAINT_NAME%TYPE
	IS
		v_message MY_CONSTRAINTS.CONSTRAINT_NAME%TYPE;
		
	BEGIN
		SELECT mc.message INTO v_message FROM my_constraints mc
		WHERE mc.constraint_name = LOWER(p_constraint_name);
		
		RETURN v_message;
		
	EXCEPTION 
		WHEN NO_DATA_FOUND THEN
			RETURN NULL;
		
	END get_constraint_message;
	/* END get_constraint_message */
	
	
	-----------------------------------------
	-- PUBLIC PROCEDURES AND FUNCTIONS
	-----------------------------------------
	
	/* BEGIN report_and_stop */
	PROCEDURE report_and_stop 
	(
		p_subprog		 IN 	VARCHAR2,
		p_errcode		 IN		INTEGER	:= SQLCODE,
		p_errmsg		 IN  	VARCHAR2:= NULL,
		p_append_sqlerrm IN		BOOLEAN	:= FALSE,
		p_strip_code	 IN 	BOOLEAN	:= FALSE
	) 
	IS
	
	BEGIN
		handle (
					p_errcode,
					format_message (p_subprog, p_errcode, p_errmsg, p_append_sqlerrm, p_strip_code),
					true,
					true
				);
				
	END report_and_stop;
	/* END report_and_stop */

	
	/* BEGIN report_and_go */
	PROCEDURE report_and_go 
	(
      p_subprog		 IN 	VARCHAR2,
		p_errcode		 IN		INTEGER	:= SQLCODE,
		p_errmsg		 IN  	VARCHAR2:= NULL,
		p_append_sqlerrm IN		BOOLEAN	:= FALSE,
		p_strip_code	 IN 	BOOLEAN	:= FALSE
	) 
	IS
	
	BEGIN
		handle (
					p_errcode,
					format_message (p_subprog, p_errcode, p_errmsg, p_append_sqlerrm, p_strip_code),
					true,
					false
				);
				
	END report_and_go;
	/* END report_and_go*/

	
	/* BEGIN logto */
	-- Initialization before all, for procedure log especially
	PROCEDURE logto 
	(
		p_target IN PLS_INTEGER,
		p_dir    IN VARCHAR2 := NULL,
		p_file   IN VARCHAR2 := NULL
	) 
	IS
	
	BEGIN
		g_target    := p_target;
		g_file      := NVL(p_file, g_file);
		g_dir       := p_dir;
		
	END logto;
	/* END logto */
	
	
	/* BEGIN assert */
	PROCEDURE assert 
	(
		p_condition       IN 	BOOLEAN,
		p_message         IN 	VARCHAR2,
		p_raise_exception IN 	BOOLEAN := TRUE,
		p_exception_name  IN 	VARCHAR2 := 'VALUE_ERROR'
	) 
	IS
		v_msg	T_ERR_MSG_FORMATED;
	
	BEGIN
	
		IF NOT p_condition OR p_condition IS NULL THEN
			DBMS_OUTPUT.PUT_LINE('Assertion Failure!');
			DBMS_OUTPUT.PUT_LINE(p_message);
			-- By default p_errcode = NULL
			v_msg.f_default_msg := 'Assertion failure: ' || p_message;
			log(p_errmsg => v_msg);

			IF p_raise_exception THEN
				EXECUTE IMMEDIATE 'BEGIN RAISE ' || p_exception_name || '; END;';
			END IF;
		
		END IF;
		
	END assert;
	/* END assert */
   
   
    /* BEGIN get_error_message */
    FUNCTION get_error_message 
	(
		p_default_message 	IN 	MY_CONSTRAINTS.MESSAGE%TYPE
	)
	RETURN MY_CONSTRAINTS.MESSAGE%TYPE
	IS
		v_message MY_CONSTRAINTS.MESSAGE%TYPE;
		
	BEGIN
		v_message := PACK_ERROR.get_constraint_message(PACK_ERROR.find_constraint_name);
		v_message := NVL(v_message, p_default_message);
		
	RETURN v_message;
		
	END get_error_message;
	/* END get_error_message */
	

END PACK_ERROR;
/