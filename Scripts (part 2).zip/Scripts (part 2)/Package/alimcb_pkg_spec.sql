CREATE OR REPLACE PACKAGE ALIMCB_PKG AS 

PROCEDURE 	alimMovieById_pr(movie_id movie.id%TYPE);
PROCEDURE 	alimMovieByN_pr(n integer);
FUNCTION 	filter_title_fc(t VARCHAR2) RETURN VARCHAR2;
FUNCTION 	filter_status_fc(s VARCHAR2) RETURN VARCHAR2;
FUNCTION 	filter_tagline_fc(tag VARCHAR2) RETURN VARCHAR2;
FUNCTION 	get_blob_fc(url VARCHAR2) RETURN BLOB;

/**************************** ACTORS ***************************************************/
PROCEDURE 	split_actors_fc (p_actors VARCHAR2 , mv_id movie.id%TYPE);
PROCEDURE 	fill_artist_pr (p_id artist.id%TYPE , p_name artist.name%TYPE);
PROCEDURE 	merge_play_pr(mv_id movie.id%TYPE, a_id artist.id%TYPE);

/**************************** DIRECTORS *************************************************/
PROCEDURE 	split_directors_pr(p_director VARCHAR2, mv_id movie.id%TYPE);
PROCEDURE 	merge_direct_pr(mv_id movie.id%TYPE, a_id artist.id%TYPE);

/**************************** CERTIFICATIONS ********************************************/
PROCEDURE 	fill_certification_pr(p_cert certification.id%TYPE, mv_id movie.id%TYPE);

/**************************** GENRES*****************************************************/
PROCEDURE 	split_genre_pr (p_genre VARCHAR2 , mv_id movie.id%TYPE);
PROCEDURE 	fill_genre_pr (p_id genre.id%TYPE , p_name genre.name%TYPE);
PROCEDURE 	merge_genre_movie_pr(mv_id movie.id%TYPE, a_id genre.id%TYPE);


END ALIMCB_PKG;