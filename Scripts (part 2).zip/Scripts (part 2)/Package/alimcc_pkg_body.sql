-- ###############################
-- # PACKAGE ALIMCC BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_ALIMCC
IS 
	/* BEGIN ALIMCC_BY_XML */
	PROCEDURE alimcc_by_xml
	IS
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_ALIMCC.PROC_ALIMCC_BY_XML';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_alimentation_cc';
		
	BEGIN
		PACK_ALIMCC.get_xml;
		-- Transfert of the clobs
		PACK_MANAGECLOB.get_cmovie_from_cb@db_cc@renequinpolis;
		PACK_MANAGECLOB.get_ccopy_from_cb@db_cc@renequinpolis;
		DELETE FROM remote_copy;
		DELETE FROM remote_movie;
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END alimcc_by_xml;					
	/* END ALIMCC_BY_XML*/
	
	/* BEGIN GET_XML */
	PROCEDURE get_xml
	IS
		CURSOR movie_cur IS
			SELECT * FROM movie;
		
		TYPE list_movies_type IS
			TABLE OF MOVIE%ROWTYPE INDEX BY BINARY_INTEGER;
		TYPE list_copies_type IS
			TABLE OF COPY%ROWTYPE INDEX BY BINARY_INTEGER;
			
		v_list_movies	list_movies_type;
		v_list_copies	list_copies_type;
		v_nb_copies		INTEGER;
		v_movie_xml		XMLTYPE;
		v_copy_xml		XMLTYPE;
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_ALIMCC.PROC_GET_XML';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_récupération_données_xml';
		
	BEGIN
		OPEN movie_cur;
		LOOP
			FETCH movie_cur BULK COLLECT INTO v_list_movies;
			DBMS_OUTPUT.PUT_LINE('Nb of movies :' || v_list_movies.COUNT);
			
			FOR indx IN 1..v_list_movies.COUNT
			LOOP
				v_nb_copies := RANDOM_UNIFORM(v_list_movies(indx).nb_copies);
				DBMS_OUTPUT.PUT_LINE('Nb of copies :' || v_nb_copies ||' for the movie:' || v_list_movies(indx).id);
				
				IF (v_nb_copies <= v_list_movies(indx).nb_copies AND v_nb_copies != 0 AND v_list_movies(indx).nb_copies > 0) THEN
				
					-- Decrement nb_copies in movie table
					UPDATE movie m SET m.nb_copies = (v_list_movies(indx).nb_copies - v_nb_copies)
					WHERE m.id = v_list_movies(indx).id;
					COMMIT;
					-- Generate xml for the movie
					v_movie_xml := PACK_GENXMLFROMSQL.gen_xml_movie(v_list_movies(indx).id);
					-- Insert into local table remote 
					INSERT INTO remote_movie VALUES (v_movie_xml.getClobVal());
					COMMIT;
					
					SELECT * BULK COLLECT INTO v_list_copies 
					FROM copy c 
					WHERE c.id_movie = v_list_movies(indx).id 
					AND ROWNUM <= v_nb_copies;
					
					FOR i IN 1..v_list_copies.COUNT
					LOOP
						-- Generate xml for the copy
						v_copy_xml := PACK_GENXMLFROMSQL.gen_xml_copy(v_list_copies(i).num, v_list_copies(i).id_movie);
						-- Delete copies in copy table
						DELETE FROM copy c WHERE c.num = v_list_copies(i).num AND c.id_movie = v_list_copies(i).id_movie;
						COMMIT;
						DBMS_OUTPUT.PUT_LINE('Copy deleted : ('|| v_list_copies(i).num || ','||v_list_copies(i).id_movie||')');
						-- Insert into local table remote
						INSERT INTO remote_copy VALUES (v_copy_xml.getClobVal());
						COMMIT;
					END LOOP;
					
				END IF;
			END LOOP;
			EXIT WHEN movie_cur%NOTFOUND;
		END LOOP;	
		COMMIT;
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END get_xml;					
	/* END GET_XML*/
	
END PACK_ALIMCC ;
/