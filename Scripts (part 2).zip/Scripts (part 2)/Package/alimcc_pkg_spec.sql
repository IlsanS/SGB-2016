-- ###############################
-- # CREATE PACKAGE ALIMCC
-- ###############################
CREATE OR REPLACE PACKAGE PACK_ALIMCC
IS
	-- Alim CC
	PROCEDURE alimcc_by_xml;
	
	-- Get values
	PROCEDURE get_xml;

END PACK_ALIMCC;
/	