CREATE OR REPLACE PACKAGE BODY ANALYSIS_PKG AS

/**********************************************************************
             WRITEFILE_PR 
***********************************************************************/
PROCEDURE writeFile_pr(message VARCHAR, quantil NUMBER) 
IS  
	fileHandler UTL_FILE.FILE_TYPE;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.WRITEFILE_PR';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_écriture_fichier';
	
BEGIN
	fileHandler := UTL_FILE.FOPEN('SRC_DIR', 'stat_file.txt', 'A');
    UTL_FILE.PUTF(fileHandler,message);
    UTL_FILE.PUTF(fileHandler,'  ');
    UTL_FILE.PUTF(fileHandler,quantil);  
    UTL_FILE.FCLOSE(fileHandler);
	
EXCEPTION
    WHEN utl_file.invalid_path THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_file, 'invalid_path_for_file', TRUE);
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_file, c_type_err, TRUE);
		
END writeFile_pr;


/**************************************************************************************************************
			 ANALYSE_PR
*************************************************************************************************************/
PROCEDURE analyse_pr
IS 
	-- Location of the error/logging
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.WRITEFILE_PR';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_écriture_fichier';
	-- Type of the logging
	c_type_log	CONSTANT LOGGING_ERRORS.message%TYPE := 'fichier_stat_généré_avec_réussite';
	
	CURSOR movie_ext_cur IS
	WITH 
    title(q_title,qq_title, moy_title, sd_title, med_title, min_title, max_title) 
	AS 
    ( 
		SELECT 	percentile_cont(0.99) within GROUP (ORDER BY LENGTH(title)) VALUE,
				percentile_cont(0.999) within GROUP (ORDER BY LENGTH(title)) VALUE,
				AVG(LENGTH(title)),
				STDDEV(LENGTH(title)),
				MEDIAN(LENGTH(title)),
				MIN(LENGTH(title)),
				MAX(LENGTH(title))
		FROM movies_ext
    ),
	 
    tagline(q_tagline,qq_tagline, moy_tagline, sd_tagline, med_tagline, min_tagline, max_tagline) 
	AS 
    ( 
		SELECT  percentile_cont(0.99) within GROUP (ORDER BY LENGTH(tagline)) VALUE,
				percentile_cont(0.999) within GROUP (ORDER BY LENGTH(tagline)) VALUE,
				AVG(LENGTH(tagline)),
				STDDEV(LENGTH(tagline)),
				MEDIAN(LENGTH(tagline)),
				MIN(LENGTH(tagline)),
				MAX(LENGTH(tagline))
		FROM movies_ext
    ),

    genre(q_genre,moy_genre, sd_genre, med_genre, min_genre, max_genre, max_id_genre) 
	AS
    ( 
		SELECT 	percentile_cont(0.99) within GROUP (ORDER BY LENGTH(nom)) VALUE,
				AVG(LENGTH(nom)),
				STDDEV(LENGTH(nom)),
				MEDIAN(LENGTH(nom)),
				MIN(LENGTH(nom)),
				MAX(LENGTH(nom)),
				MAX(id) 
		FROM table(split_genre_fc)
    ),

    directeur(q_directeur,qq_directeur ,moy_directeur, sd_directeur, med_directeur, min_directeur, max_directeur, max_id_directeur) 
	AS
    ( 
		SELECT 	percentile_cont(0.99) within GROUP (ORDER BY LENGTH( nom)) VALUE,
				percentile_cont(0.999) within GROUP (ORDER BY LENGTH( nom)) VALUE,
				AVG(LENGTH(nom)),
				STDDEV(LENGTH(nom)),
				MEDIAN(LENGTH(nom)),
				MIN(LENGTH(nom)),
				MAX(LENGTH(nom)),
				MAX(id) 
		FROM table(split_director_fc)
    ),

    acteur (q_acteur,qq_acteur,moy_acteur, sd_acteur, med_acteur, min_acteur, max_acteur, max_id_acteur) 
	AS
    ( 
		SELECT 	percentile_cont(0.99) within GROUP (ORDER BY LENGTH( nom)) VALUE,
				percentile_cont(0.999) within GROUP (ORDER BY LENGTH( nom)) VALUE,
				AVG(LENGTH(nom)),
				STDDEV(LENGTH(nom)),
				MEDIAN(LENGTH(nom)),
				MIN(LENGTH(nom)),
				MAX(LENGTH(nom)),
				MAX(id) 
		FROM table(split_actor_fc)
    ),

	runtime(moy_runtime, min_runtime, max_runtime)
	AS 
	(
		SELECT AVG(runtime),MIN(runtime), MAX(runtime) FROM movies_ext
	),
	
    runtime_2(nb_null_runtime)
	AS 
	(
		SELECT COUNT(*) FROM movies_ext WHERE runtime=0
	),

	vote_average(moy_vote_Average, min_vote_average,max_vote_Average) 
	AS 
	(
		SELECT AVG(vote_average),MIN(vote_average), MAX(vote_average) FROM movies_ext
	),
	
    vote_average_2(nb_null_vote_average) 
	AS 
	( 
		SELECT vote_average FROM movies_ext WHERE vote_average=0
	),

    budget(moy_budget, min_budget,max_budget) 
	AS 
	(
		SELECT AVG(budget), MIN(budget), MAX(budget) FROM movies_ext
	),
	
    budget_2(nb_null_budget) 
	AS 
	( 
		SELECT COUNT(*) FROM movies_ext WHERE budget<=0
	)
	SELECT * FROM title, tagline,genre, directeur, acteur, runtime, runtime_2, vote_average,vote_average_2, budget, budget_2;

	rowcur_var  movie_ext_cur%ROWTYPE;
	
	BEGIN
		OPEN movie_ext_cur;
			FETCH movie_ext_cur INTO rowcur_var;
			-- LOOP
			-- EXIT WHEN movie_ext_cur%NOTFOUND;

				ANALYSIS_PKG.writeFile_pr('titres 99ème quantil :',rowcur_var.q_title);
				ANALYSIS_PKG.writeFile_pr('titres 999ème quantil :',rowcur_var.qq_title);
				ANALYSIS_PKG.writeFile_pr('titres moyenne :',rowcur_var.moy_title);
				ANALYSIS_PKG.writeFile_pr('titres ecart type :',rowcur_var.sd_title);
				ANALYSIS_PKG.writeFile_pr('titres MEDIAN :',rowcur_var.med_title);
				ANALYSIS_PKG.writeFile_pr('titres longeur MIN :',rowcur_var.min_title);
				ANALYSIS_PKG.writeFile_pr('titres longeur MAX :',rowcur_var.max_title);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('taglines 99ème quantil :',rowcur_var.q_tagline);
				ANALYSIS_PKG.writeFile_pr('taglines 999ème quantil :',rowcur_var.qq_tagline);
				ANALYSIS_PKG.writeFile_pr('taglines moyenne :',rowcur_var.moy_tagline);
				ANALYSIS_PKG.writeFile_pr('taglines ecart type :',rowcur_var.sd_tagline);
				ANALYSIS_PKG.writeFile_pr('taglines longeur MIN :',rowcur_var.min_tagline);
				ANALYSIS_PKG.writeFile_pr('taglines longeur MAX :',rowcur_var.max_tagline);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('genres 99ème quantil :',rowcur_var.q_genre);
				ANALYSIS_PKG.writeFile_pr('genres moyenne :',rowcur_var.moy_genre);
				ANALYSIS_PKG.writeFile_pr('genres ecart type :',rowcur_var.sd_genre);
				ANALYSIS_PKG.writeFile_pr('genres longeur MIN :',rowcur_var.min_genre);
				ANALYSIS_PKG.writeFile_pr('genres longeur MAX :',rowcur_var.max_genre);
				ANALYSIS_PKG.writeFile_pr('id_genre MAX :',rowcur_var.max_id_genre);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('directeurs 99ème quantil :',rowcur_var.q_directeur);
				ANALYSIS_PKG.writeFile_pr('directeurs 999ème quantil :',rowcur_var.qq_directeur);
				ANALYSIS_PKG.writeFile_pr('directeurs moyenne :',rowcur_var.moy_directeur);
				ANALYSIS_PKG.writeFile_pr('directeurs ecart type :',rowcur_var.sd_directeur);
				ANALYSIS_PKG.writeFile_pr('directeurs longeur MIN :',rowcur_var.min_directeur);
				ANALYSIS_PKG.writeFile_pr('directeurs longeur MAX :',rowcur_var.max_directeur);
				ANALYSIS_PKG.writeFile_pr('id_directeurs MAX :',rowcur_var.max_id_directeur);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('acteurs 99ème quantil :',rowcur_var.q_acteur);
				ANALYSIS_PKG.writeFile_pr('acteurs 999ème quantil :',rowcur_var.qq_acteur);
				ANALYSIS_PKG.writeFile_pr('acteurs moyenne :',rowcur_var.moy_acteur);
				ANALYSIS_PKG.writeFile_pr('acteurs ecart type :',rowcur_var.sd_acteur);
				ANALYSIS_PKG.writeFile_pr('acteurs longeur MIN :',rowcur_var.min_acteur);
				ANALYSIS_PKG.writeFile_pr('acteurs longeur MAX :',rowcur_var.max_acteur);
				ANALYSIS_PKG.writeFile_pr('id_acteurs MAX :',rowcur_var.max_id_acteur);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('runtime valeur MAX :',rowcur_var.max_runtime);
				ANALYSIS_PKG.writeFile_pr('runtime valeur MIN :',rowcur_var.min_runtime);
				ANALYSIS_PKG.writeFile_pr('runtime valeur nulle :',rowcur_var.nb_null_runtime);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('vote moyen valeur MAX :',rowcur_var.max_vote_Average);
				ANALYSIS_PKG.writeFile_pr('vote moyen valeur MIN :',rowcur_var.min_vote_average);
				ANALYSIS_PKG.writeFile_pr('vote moyen valeur nulle :',rowcur_var.nb_null_vote_average);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

				ANALYSIS_PKG.writeFile_pr('budget valeur MAX :',rowcur_var.max_budget);
				ANALYSIS_PKG.writeFile_pr('budget valeur MIN :',rowcur_var.min_budget);
				ANALYSIS_PKG.writeFile_pr('budget valeur nulle :',rowcur_var.nb_null_budget);
				ANALYSIS_PKG.writeFile_pr('************************************************************************************************************:',0);

			--END LOOP;
		CLOSE movie_ext_cur;
		print_genres_pr;
		print_status_pr;
		print_certification_pr;
		PACK_LOGGING.addLogState(NULL, c_loca, 'stat_file.txt generated', c_type_log);
		
EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_file, c_type_err, TRUE);
		
END analyse_pr; 


/**************************************************************************************************************
             SPLIT_GENRE_FC
*************************************************************************************************************/
FUNCTION split_genre_fc RETURN nomId_tab
AS
	id_nom nomId_tab;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.SPLIT_GENRE_FC';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_extraction_genres';
	
BEGIN 
	WITH Split(genre,stpos,endpos)
	AS
	(
        SELECT genres, 0 AS stpos,  REGEXP_INSTR(genres,'‖')   AS endpos FROM movies_ext 
        UNION ALL
        SELECT genre, endpos+1,  REGEXP_INSTR(genre,'‖',endpos+1)
            FROM Split
            WHERE endpos > 0
    )

    SELECT DISTINCT nomId(regexp_substr(SUBSTR(genre,stpos,COALESCE(NULLIF(endpos,0),LENGTH(genre)+1)-stpos),'[A-Z ]+',1,1) ,
    TO_NUMBER(regexp_substr(SUBSTR(genre,stpos,COALESCE(NULLIF(endpos,0),LENGTH(genre)+1)-stpos),'[0-9]+',1,1)))
    BULK COLLECT into id_nom
    FROM Split ;
	
	RETURN id_nom;
	
EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_split, c_type_err, TRUE);
	
END split_genre_fc;


/**************************************************************************************************************
             SPLIT_DIRECTOR_FC
*************************************************************************************************************/
FUNCTION split_director_fc RETURN nomId_tab
AS
	id_nom nomId_tab;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.SPLIT_DIRECTOR_FC';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_extraction_réalisateurs';
  
BEGIN 
	WITH Split(director,stpos,endpos)
	AS
	(
		SELECT directors, 0 AS stpos,  REGEXP_INSTR(directors,'‖')   AS endpos FROM movies_ext 
        UNION ALL
        SELECT director, endpos+1,  REGEXP_INSTR(director,'‖',endpos+1)
            FROM Split
            WHERE endpos > 0
    )

    SELECT DISTINCT nomId(regexp_substr(SUBSTR(director,stpos,COALESCE(NULLIF(endpos,0),LENGTH(director)+1)-stpos),'[A-Z /. /-/öä]+',1,1) ,
    TO_NUMBER(regexp_substr(SUBSTR(director,stpos,COALESCE(NULLIF(endpos,0),LENGTH(director)+1)-stpos),'[0-9]+',1,1)))
    BULK COLLECT into id_nom
    FROM Split  ;
	
	RETURN id_nom;

EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_split, c_type_err, TRUE);
	
END split_director_fc;


/**************************************************************************************************************
             SPLIT_ACTOR_FC
*************************************************************************************************************/
FUNCTION split_actor_fc RETURN nomId_tab
AS
	id_nom nomId_tab;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.SPLIT_ACTOR_FC';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_extraction_acteurs';
  
BEGIN 
	WITH Split(actor,stpos,endpos)
	AS
	(
        SELECT actors, 0 AS stpos,  REGEXP_INSTR(actors,'‖') AS endpos FROM movies_ext 
        UNION ALL
        SELECT actor, endpos+1,  REGEXP_INSTR(actor,'‖',endpos+1)
            FROM Split
            WHERE endpos > 0
    )

    SELECT DISTINCT nomId(regexp_substr(SUBSTR(actor,stpos,COALESCE(NULLIF(endpos,0),LENGTH(actor)+1)-stpos),'[A-Z /. /-/öä]+',1,1) ,
    to_number(regexp_substr(SUBSTR(actor,stpos,COALESCE(NULLIF(endpos,0),LENGTH(actor)+1)-stpos),'[0-9]+',1,1)))
    BULK COLLECT into id_nom
    FROM Split;
	
	RETURN id_nom;

EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_split, c_type_err, TRUE);
	
END split_actor_fc;


/******************************************************************************************************************
             PRINT_STATUS_PR
******************************************************************************************************************/
PROCEDURE print_status_pr
AS 
    fileHandler UTL_FILE.FILE_TYPE;
    nb_null number;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.PRINT_STATUS_PR';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_écriture_status_fichier';

BEGIN
	SELECT COUNT(*)  into nb_null FROM movies_ext WHERE status is null;
	fileHandler := UTL_FILE.FOPEN('SRC_DIR', 'test_file.txt', 'A');
    UTL_FILE.PUTF(fileHandler,'Status distincts.\n Nombre de nuls :'||nb_null ||'\n');
	FOR v_cursor IN (SELECT DISTINCT status FROM movies_ext)
        LOOP
            UTL_FILE.put_line (fileHandler, v_cursor.status);
        END LOOP;
		UTL_FILE.fclose (fileHandler);
		
EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_file, c_type_err, TRUE);

END print_status_pr;


/**************************************************************************************************************
             PRINT_CERTIFICATION_PR
*************************************************************************************************************/
PROCEDUre print_certification_pr
AS
    fileHandler UTL_FILE.FILE_TYPE;
    nb_null number;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.PRINT_CERTIFICATION_PR';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_écriture_certifications_fichier';

BEGIN
	SELECT COUNT(*) into nb_null FROM movies_ext WHERE certification is null;
	fileHandler := UTL_FILE.FOPEN('SRC_DIR', 'test_file.txt', 'A');
	UTL_FILE.PUTF(fileHandler,'certifications distinctes.\n Nombre de nuls :'||nb_null ||'\n');
	FOR v_cursor IN (SELECT DISTINCT certification FROM movies_ext)
	    LOOP
			UTL_FILE.put_line (fileHandler, v_cursor.certification);	
		END LOOP;
        UTL_FILE.fclose (fileHandler);
EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_file, c_type_err, TRUE);

END print_certification_pr;


/**************************************************************************************************************
             PRINT_GENRES_PR
************************************************************************************************************/
PROCEDURE print_genres_pr
AS
    fileHandler UTL_FILE.FILE_TYPE;
    nb_null number;
	-- Location of the error
	c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'ANALYSIS_PKG.PRINT_GENRES_PR';
	-- Type of the error
	c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_écriture_genre_fichier';

BEGIN
	SELECT COUNT(*) into nb_null FROM movies_ext WHERE genres is null;
	fileHandler := UTL_FILE.FOPEN('SRC_DIR', 'test_file.txt', 'A');
	UTL_FILE.PUTF(fileHandler,'Genres distincts.\n Nombre de nuls :'||nb_null ||'\n');
	FOR v_cursor IN (SELECT nom FROM table( split_genre_fc))
		LOOP
			UTL_FILE.put_line (fileHandler, v_cursor.nom);
		END LOOP;
	UTL_FILE.fclose (fileHandler);
	
EXCEPTION
	WHEN OTHERS THEN 
		PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_file, c_type_err, TRUE);

END print_genres_pr;


END ANALYSIS_PKG;

