CREATE OR REPLACE PACKAGE ANALYSIS_PKG AS 

PROCEDURE 	writeFile_pr(message VARCHAR, quantil NUMBER);

PROCEDURE 	analyse_pr;

FUNCTION 	split_genre_fc 		RETURN nomId_tab;
FUNCTION 	split_director_fc 	RETURN nomId_tab;
FUNCTION 	split_actor_fc 		RETURN nomId_tab;

PROCEDURE 	print_status_pr;
PROCEDURE	print_certification_pr;
PROCEDURE 	print_genres_pr;
 
 
END ANALYSIS_PKG;