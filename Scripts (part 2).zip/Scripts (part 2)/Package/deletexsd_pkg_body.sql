-- ###############################
-- # PACKAGE DELETEXSD BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_DELETEXSD
IS 
	/* BEGIN DELETE_XSD */
	PROCEDURE delete_xsd
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd';
		
	BEGIN
		PACK_DELETEXSD.delete_xsd_user;
		PACK_DELETEXSD.delete_xsd_movie;
		PACK_DELETEXSD.delete_xsd_certification;
		PACK_DELETEXSD.delete_xsd_artist;
		PACK_DELETEXSD.delete_xsd_copy;
		PACK_DELETEXSD.delete_xsd_cert_movie;
		PACK_DELETEXSD.delete_xsd_direct;
		PACK_DELETEXSD.delete_xsd_errors;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd;					
	/* FIN DELETE_XSD*/
	
	/* BEGIN DELETE_XSD_USER */
	PROCEDURE delete_xsd_user
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_USER';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_utilisateur';
		
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/user.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_user;					
	/* FIN DELETE_XSD_USER*/
	
	/* BEGIN DELETE_XSD_MOVIE */
	PROCEDURE delete_xsd_movie
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_MOVIE';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_film';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/movie.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_movie;					
	/* FIN DELETE_XSD_MOVIE*/
	
	/* BEGIN DELETE_XSD_CERTIFICATION */
	PROCEDURE delete_xsd_certification
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_CERTIFICATION';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_certification';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/certification.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_certification;					
	/* FIN DELETE_XSD_CERTIFICATION*/
	
	/* BEGIN DELETE_XSD_ARTIST */
	PROCEDURE delete_xsd_artist
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_ARTIST';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_artiste';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/artist.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_artist;					
	/* FIN DELETE_XSD_ARTIST*/
	
	/* BEGIN DELETE_XSD_COPY */
	PROCEDURE delete_xsd_copy
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_COPY';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_copie';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/copy.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_copy;					
	/* FIN DELETE_XSD_COPY*/
	
	/* BEGIN DELETE_XSD_CERT_MOVIE */
	PROCEDURE delete_xsd_cert_movie
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_CERT_MOVIE';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_certification_film';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/cert_movie.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_cert_movie;					
	/* FIN DELETE_XSD_CERT_MOVIE*/
	
	/* BEGIN DELETE_XSD_DIRECT */
	PROCEDURE delete_xsd_direct
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_DIRECT';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_réalise';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/direct.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_direct;					
	/* FIN DELETE_XSD_DIRECT*/
	
	/* BEGIN DELETE_XSD_ERRORS */
	PROCEDURE delete_xsd_errors
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_DELETEXSD.PROC_DELETE_XSD_ERRORS';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_effacement_xsd_erreurs';
		
	BEGIN
		DBMS_XMLSCHEMA.deleteschema
		(
			schemaurl		=> 	'http://www.rennequinpolis.be/logging_errors.xsd',
			delete_option	=> 	DBMS_XMLSCHEMA.DELETE_CASCADE_FORCE
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END delete_xsd_errors;					
	/* FIN DELETE_XSD_ERRORS*/
	
END PACK_DELETEXSD ;
/