-- ###############################
-- # CREATE PACKAGE DELETEXSD
-- ###############################
CREATE OR REPLACE PACKAGE PACK_DELETEXSD 
IS
	-- Delete all the schemas
	PROCEDURE delete_xsd;
	
	-- Delete schema of table user_movie_xml
	PROCEDURE delete_xsd_user;
	
	-- Delete schema of table movie_xml
	PROCEDURE delete_xsd_movie;
	
	-- Delete schema of table certification_xml
	PROCEDURE delete_xsd_certification;
	
	-- Delete schema of table artist_xml
	PROCEDURE delete_xsd_artist;
	
	-- Delete schema of table copy_xml
	PROCEDURE delete_xsd_copy;
	
	-- Delete schema of table cert_movie_xml
	PROCEDURE delete_xsd_cert_movie;
	
	-- Delete schema of table direct_xml
	PROCEDURE delete_xsd_direct;
	
	-- Delete schema of table logging_errors
	PROCEDURE delete_xsd_errors;
	
END PACK_DELETEXSD;
/	
	