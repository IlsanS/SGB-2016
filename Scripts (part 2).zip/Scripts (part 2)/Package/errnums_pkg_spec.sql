CREATE OR REPLACE PACKAGE ERRNUMS_PKG AS

	validation_ex EXCEPTION;
	validation_const CONSTANT NUMBER := -20001;
	PRAGMA exception_init (validation_ex, -20001);
	
	insertion_ex EXCEPTION;
	insertion_const CONSTANT NUMBER := -20002;
	PRAGMA exception_init (insertion_ex, -20002);
  
	user_add_ex EXCEPTION;
	user_add_const CONSTANT NUMBER := -20003;
	PRAGMA exception_init (insertion_ex, -20003);
  
	user_read_ex EXCEPTION;
	user_read_const CONSTANT NUMBER := -20004;
	PRAGMA exception_init (insertion_ex, -20004);

	user_update_ex EXCEPTION;
	user_update_const CONSTANT NUMBER := -20007;
	PRAGMA exception_init (insertion_ex, -20007);
  
	user_del_ex EXCEPTION;
	user_del_const CONSTANT NUMBER := -20009;
	PRAGMA exception_init (insertion_ex, -20009);
  
  
	user_eval_ex EXCEPTION;
	user_eval_const CONSTANT NUMBER := -20010;
	PRAGMA exception_init (insertion_ex, -20010);

	WriteFile_ex EXCEPTION;
	WriteFile_const CONSTANT NUMBER := -20011;
	PRAGMA exception_init (WriteFile_ex, -20011);

	Analyse_ex EXCEPTION;
	Analyse_const CONSTANT NUMBER := -20012;
	PRAGMA exception_init (Analyse_ex, -20012);

END errnums_pkg;
/