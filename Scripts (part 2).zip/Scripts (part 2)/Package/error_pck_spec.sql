CREATE OR REPLACE PACKAGE ERR_PKG AS

	c_table 		CONSTANT PLS_INTEGER := 1; -- Default
	c_file 			CONSTANT PLS_INTEGER := 2;
	c_screen 		CONSTANT PLS_INTEGER := 4;

  PROCEDURE report_and_stop 
  (
	subprog 		IN VARCHAR2,
    errcode 		IN INTEGER 	 := SQLCODE,
    errmsg  		IN VARCHAR2  := NULL,
    append_sqlerrm 	IN BOOLEAN   := FALSE,
    strip_code 		IN BOOLEAN   := FALSE
  );

  PROCEDURE report_and_go 
  (
    subprog 		IN VARCHAR2,
    errcode 		IN INTEGER   := SQLCODE,
    errmsg  		IN VARCHAR2  := NULL,
    append_sqlerrm 	IN BOOLEAN   := FALSE,
    strip_code 		IN BOOLEAN   := FALSE
  );

  PROCEDURE logto 
  (
    target 			IN PLS_INTEGER,
    dir    			IN VARCHAR2  := NULL,
    file   			IN VARCHAR2  := NULL
  );

  PROCEDURE assert 
  (
    condition       IN BOOLEAN,
    message         IN VARCHAR2,
    raise_exception IN BOOLEAN  := TRUE,
    exception_name  IN VARCHAR2 := 'VALUE_ERROR'
  );
  
  
END err_pkg;
/
