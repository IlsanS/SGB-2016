-- ###############################
-- # PACKAGE GENXMLFROMSQL BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_GENXMLFROMSQL
IS 
	/* BEGIN GEN_XML_MOVIE */
	FUNCTION gen_xml_movie
	(
		p_idMovie	IN 	MOVIE.id%TYPE,
		p_is_nb_cop	IN 	BOOLEAN := FALSE
	)
	RETURN XMLTYPE
	IS
		v_filename			VARCHAR2(50);
		v_nb_cop			INTEGER;
	
		v_xmltype			XMLTYPE;
		v_dom_doc			DBMS_XMLDOM.DOMDocument;
		v_root_node			DBMS_XMLDOM.DOMNode;
		
		v_movie_element		DBMS_XMLDOM.DOMElement;
		v_movie_node		DBMS_XMLDOM.DOMNode;
		
		v_id_element		DBMS_XMLDOM.DOMElement;
		v_id_node			DBMS_XMLDOM.DOMNode;
		v_id_text			DBMS_XMLDOM.DOMText;
		v_id_textnode		DBMS_XMLDOM.DOMNode;
		
		v_title_element		DBMS_XMLDOM.DOMElement;
		v_title_node		DBMS_XMLDOM.DOMNode;
		v_title_text		DBMS_XMLDOM.DOMText;
		v_title_textnode	DBMS_XMLDOM.DOMNode;
		
		v_poster_element	DBMS_XMLDOM.DOMElement;
		v_poster_node		DBMS_XMLDOM.DOMNode;
		v_poster_text		DBMS_XMLDOM.DOMText;
		v_poster_textnode	DBMS_XMLDOM.DOMNode;
		
		v_nb_cop_element	DBMS_XMLDOM.DOMElement;
		v_nb_cop_node		DBMS_XMLDOM.DOMNode;
		v_nb_cop_text		DBMS_XMLDOM.DOMText;
		v_nb_cop_textnode	DBMS_XMLDOM.DOMNode;
		
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_GENXMLFROMSQL.PROC_GEN_XML_MOVIE';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_génération_document_xml_film';
		
	BEGIN
		v_dom_doc		:=	DBMS_XMLDOM.newDomDocument;
		v_root_node		:= 	DBMS_XMLDOM.makeNode(v_dom_doc);
		v_movie_element	:= 	DBMS_XMLDOM.createElement(v_dom_doc,'movie');
		DBMS_XMLDOM.setAttribute(v_movie_element, 'xmlns', 'http://www.rennequinpolis.be/movie.xsd');
		v_movie_node	:= 	DBMS_XMLDOM.appendChild(v_root_node, DBMS_XMLDOM.makeNode(v_movie_element));
		
		FOR m_reg IN 
		(
			SELECT m.id, m.title, m.nb_copies, p.poster
			FROM movie m, (SELECT (DBMS_LOB.SUBSTR(poster)) AS poster FROM movie WHERE id=p_idMovie) p
			WHERE m.id = p_idMovie
		)
			LOOP 
				v_id_element		:=	DBMS_XMLDOM.createElement(v_dom_doc,'id');
				v_id_node			:=	DBMS_XMLDOM.appendChild(v_movie_node, DBMS_XMLDOM.makeNode(v_id_element));
				v_id_text			:=  DBMS_XMLDOM.createTextNode(v_dom_doc, m_reg.id);
				v_id_textnode		:= 	DBMS_XMLDOM.appendChild(v_id_node, DBMS_XMLDOM.makeNode(v_id_text));
				
				v_title_element		:=	DBMS_XMLDOM.createElement(v_dom_doc,'title');
				v_title_node		:=	DBMS_XMLDOM.appendChild(v_movie_node, DBMS_XMLDOM.makeNode(v_title_element));
				v_title_text		:=  DBMS_XMLDOM.createTextNode(v_dom_doc, m_reg.title);
				v_title_textnode	:= 	DBMS_XMLDOM.appendChild(v_title_node, DBMS_XMLDOM.makeNode(v_title_text));
				
				v_poster_element	:=	DBMS_XMLDOM.createElement(v_dom_doc,'poster');
				v_poster_node		:=	DBMS_XMLDOM.appendChild(v_movie_node, DBMS_XMLDOM.makeNode(v_poster_element));
				v_poster_text		:=  DBMS_XMLDOM.createTextNode(v_dom_doc, m_reg.poster);
				v_poster_textnode	:= 	DBMS_XMLDOM.appendChild(v_poster_node, DBMS_XMLDOM.makeNode(v_poster_text));
				
				IF p_is_nb_cop = FALSE THEN
					v_nb_cop := 0;
				ELSE
					v_nb_cop := m_reg.nb_copies;
				END IF;
				v_nb_cop_element	:=	DBMS_XMLDOM.createElement(v_dom_doc,'nb_copies');
				v_nb_cop_node		:=	DBMS_XMLDOM.appendChild(v_movie_node, DBMS_XMLDOM.makeNode(v_nb_cop_element));
				v_nb_cop_text		:=  DBMS_XMLDOM.createTextNode(v_dom_doc, v_nb_cop);
				v_nb_cop_textnode	:= 	DBMS_XMLDOM.appendChild(v_nb_cop_node, DBMS_XMLDOM.makeNode(v_nb_cop_text));
				
			END LOOP;
		
		v_filename := 'SRC_DIR/movie_'||p_idMovie||'.xml';
		DBMS_XMLDOM.writeToFile(v_dom_doc, v_filename);
		v_xmltype	:=	DBMS_XMLDOM.getXmlType(v_dom_doc);
		DBMS_XMLDOM.freeDocument(v_dom_doc);
		DBMS_OUTPUT.PUT_LINE(v_xmltype.getClobVal());
		
		RETURN v_xmltype;
		
	EXCEPTION 
		WHEN OTHERS THEN
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END gen_xml_movie;					
	/* END GEN_XML_MOVIE*/
	
	
	/* BEGIN GEN_XML_COPY */
	FUNCTION gen_xml_copy
	(
		p_num		IN	COPY.num%TYPE,
		p_idMovie	IN 	COPY.id_movie%TYPE	
	)
	RETURN XMLTYPE
	IS
		v_filename			VARCHAR2(50);
	
		v_xmltype			XMLTYPE;
		v_dom_doc			DBMS_XMLDOM.DOMDocument;
		v_root_node			DBMS_XMLDOM.DOMNode;
		
		v_copy_element		DBMS_XMLDOM.DOMElement;
		v_copy_node			DBMS_XMLDOM.DOMNode;
		
		v_num_element		DBMS_XMLDOM.DOMElement;
		v_num_node			DBMS_XMLDOM.DOMNode;
		v_num_text			DBMS_XMLDOM.DOMText;
		v_num_textnode		DBMS_XMLDOM.DOMNode;
		
		v_idMov_element		DBMS_XMLDOM.DOMElement;
		v_idMov_node		DBMS_XMLDOM.DOMNode;
		v_idMov_text		DBMS_XMLDOM.DOMText;
		v_idMov_textnode	DBMS_XMLDOM.DOMNode;
		
		-- Location of the error
		c_loca		LOGGING_ERRORS.location%TYPE := 'PACK_GENXMLFROMSQL.PROC_GEN_XML_COPY';
		-- Type of the error
		c_type_err	LOGGING_ERRORS.message%TYPE := 'erreur_génération_document_xml_film';
		
	BEGIN
		v_dom_doc		:=	DBMS_XMLDOM.newDomDocument;
		v_root_node		:= 	DBMS_XMLDOM.makeNode(v_dom_doc);
		v_copy_element	:= 	DBMS_XMLDOM.createElement(v_dom_doc,'copy');
		DBMS_XMLDOM.setAttribute(v_copy_element, 'xmlns', 'http://www.rennequinpolis.be/copy.xsd');
		v_copy_node		:= 	DBMS_XMLDOM.appendChild(v_root_node, DBMS_XMLDOM.makeNode(v_copy_element));
		
		FOR c_reg IN 
		(
			SELECT c.num, c.id_movie
			FROM copy c
			WHERE c.id_movie = p_idMovie AND c.num = p_num
		)
			LOOP 
				v_num_element	:=	DBMS_XMLDOM.createElement(v_dom_doc,'num');
				v_num_node		:=	DBMS_XMLDOM.appendChild(v_copy_node, DBMS_XMLDOM.makeNode(v_num_element));
				v_num_text		:=  DBMS_XMLDOM.createTextNode(v_dom_doc, c_reg.num);
				v_num_textnode	:= 	DBMS_XMLDOM.appendChild(v_num_node, DBMS_XMLDOM.makeNode(v_num_text));
				
				v_idMov_element	:=	DBMS_XMLDOM.createElement(v_dom_doc,'id_movie');
				v_idMov_node	:=	DBMS_XMLDOM.appendChild(v_copy_node, DBMS_XMLDOM.makeNode(v_idMov_element));
				v_idMov_text	:=  DBMS_XMLDOM.createTextNode(v_dom_doc, c_reg.id_movie);
				v_idMov_textnode:= 	DBMS_XMLDOM.appendChild(v_idMov_node, DBMS_XMLDOM.makeNode(v_idMov_text));
			END LOOP;
		
		v_filename := 'SRC_DIR/copy'||p_num||'_'||p_idMovie||'.xml';
		DBMS_XMLDOM.writeToFile(v_dom_doc, v_filename);
		v_xmltype	:=	DBMS_XMLDOM.getXmlType(v_dom_doc);
		DBMS_XMLDOM.freeDocument(v_dom_doc);
		DBMS_OUTPUT.PUT_LINE(v_xmltype.getClobVal());
		
		RETURN v_xmltype;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END gen_xml_copy;					
	/* END GEN_XML_COPY*/
	
END PACK_GENXMLFROMSQL ;
/