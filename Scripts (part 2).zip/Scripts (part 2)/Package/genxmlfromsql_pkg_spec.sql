-- ###############################
-- # CREATE PACKAGE GENXMLFROMSQL
-- ###############################
CREATE OR REPLACE PACKAGE PACK_GENXMLFROMSQL 
IS
	-- Generate xml from movie records
	FUNCTION gen_xml_movie
	(
		p_idMovie	IN 	MOVIE.id%TYPE,
		p_is_nb_cop	IN 	BOOLEAN := FALSE
	)
	RETURN XMLTYPE;
	
	-- Generate xml from copy records
	FUNCTION gen_xml_copy
	(
		p_num		IN	COPY.num%TYPE,
		p_idMovie	IN 	COPY.id_movie%TYPE	
	)
	RETURN XMLTYPE;
	
END PACK_GENXMLFROMSQL;
/