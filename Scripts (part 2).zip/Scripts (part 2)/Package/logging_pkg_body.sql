-- ###############################
-- # PACKAGE LOGGING BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_LOGGING 
IS 

	/* BEGIN addLogState */
	PROCEDURE addLogState
	(
		p_code			IN	LOGGING_STATES.code%TYPE,
		p_location		IN	LOGGING_STATES.location%TYPE,
		p_message		IN	LOGGING_STATES.message%TYPE,
		p_other_infos	IN  LOGGING_STATES.other_infos%TYPE
	)
	IS
		v_error_msg			LOGGING_STATES.message%TYPE;
		v_error_code      	LOGGING_STATES.code%TYPE;
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_ERROR.PROC_ADDLOGSTATE.';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'insertion_logState';
		
	BEGIN
		INSERT INTO logging_states VALUES (PACK_SEQUENCE.getIdState, p_code, p_location , p_message, p_other_infos, SYSDATE);
		COMMIT;
		
	EXCEPTION
		WHEN OTHERS THEN 
			--ROLLBACK;
			v_error_msg := SQLERRM(SQLCODE);
			v_error_code := SQLCODE;
			PACK_ERROR.report_and_stop(c_loca, v_error_code, c_type_err, true);
		
	END addLogState;					
	/* END addLogState*/

	
END PACK_LOGGING;
/