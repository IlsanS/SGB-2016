-- ###############################
-- # CREATE PACKAGE LOGGING
-- ###############################
CREATE OR REPLACE PACKAGE PACK_LOGGING
IS
	
	PROCEDURE addLogState
	(
		p_code			IN	LOGGING_STATES.code%TYPE,
		p_location		IN	LOGGING_STATES.location%TYPE,
		p_message		IN	LOGGING_STATES.message%TYPE,
		p_other_infos	IN  LOGGING_STATES.other_infos%TYPE
	);

	
END PACK_LOGGING;
/ 