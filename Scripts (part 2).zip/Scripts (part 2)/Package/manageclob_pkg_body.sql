-- ###############################
-- # PACKAGE MANAGECLOB BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_MANAGECLOB
IS 
	/* BEGIN GET_CMOVIE_FROM_CB */
	PROCEDURE get_cmovie_from_cb
	IS
		TYPE list_clob_type	IS
			TABLE OF CLOB;
			
		v_xmltype		XMLTYPE;
		v_list_movies	list_clob_type;
		v_idMovie		INTEGER;
		v_is_movie		INTEGER;
		v_is_empty		INTEGER;
		
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_MANAGECLOB.PROC_GET_CMOVIE_FROM_CB';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_récupération_clob_film';
		
	BEGIN
		INSERT INTO gtt_movie SELECT p_clob FROM REMOTE_MOVIE@db_cb@renequinpolis;
		COMMIT;
		SELECT p_clob BULK COLLECT INTO v_list_movies FROM gtt_movie;
		FOR i IN 1..v_list_movies.COUNT
		LOOP
			v_xmltype := XMLTYPE.createXml(v_list_movies(i));
			DBMS_OUTPUT.PUT_LINE(i||''||v_list_movies(i));
			
			-- Checking if the movie has been already inserted
			SELECT XMLCAST
			(
				XMLQUERY
				(
					'declare default element namespace "http://www.rennequinpolis.be/movie.xsd"; (: :)
					declare namespace m = "http://www.rennequinpolis.be/movie.xsd"; (: :)
					m:movie/m:id'
					PASSING v_xmltype RETURNING CONTENT
				)
				AS INTEGER
			) INTO v_idMovie
			FROM dual;
			
			SELECT COUNT(*) INTO v_is_empty FROM movie_xml;
			
			IF v_is_empty > 0 THEN
				SELECT COUNT(*) INTO v_is_movie FROM movie_xml WHERE EXISTSNODE
				(
					OBJECT_VALUE,
					'm:movie[m:id='||v_idMovie||']', 
					'xmlns:m="http://www.rennequinpolis.be/movie.xsd"'
				) = 1;
				-- Inserting movie if it doesn't exist yet 
				IF v_is_movie = 0 THEN 
					INSERT INTO movie_xml VALUES (v_xmltype);
					COMMIT;
				END IF;
			ELSE
				INSERT INTO movie_xml VALUES (v_xmltype);
				COMMIT;
			END IF;
			
		END LOOP;
		EXECUTE IMMEDIATE 'TRUNCATE TABLE gtt_movie'; --DELETE FROM gtt_movie;
		 
	EXCEPTION
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
			
	END get_cmovie_from_cb;					
	/* END GET_CMOVIE_FROM_CB*/
	
	/* BEGIN GET_CCOPY_FROM_CB */
	PROCEDURE get_ccopy_from_cb
	IS
		TYPE list_clob_type	IS
			TABLE OF CLOB;
			
		v_xmltype		XMLTYPE;
		v_list_copies	list_clob_type;
		v_idMovie		INTEGER;
		
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_MANAGECLOB.PROC_GET_CCOPY_FROM_CB';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_récupération_clob_copie';
		
	BEGIN
		INSERT INTO gtt_copy SELECT p_clob FROM REMOTE_COPY@db_cb@renequinpolis;
		COMMIT;
		SELECT p_clob BULK COLLECT INTO v_list_copies FROM gtt_copy;
		FOR j IN 1..v_list_copies.COUNT
		LOOP
			v_xmltype := XMLTYPE.createXml(v_list_copies(j));
			DBMS_OUTPUT.PUT_LINE(v_list_copies(j));
			INSERT INTO copy_xml VALUES(v_xmltype);
			COMMIT;
			
			-- Updating the nb_copies oh the movie
			SELECT XMLCAST
			(
				XMLQUERY
				(
					'declare default element namespace "http://www.rennequinpolis.be/copy.xsd"; (: :)
					declare namespace c = "http://www.rennequinpolis.be/copy.xsd"; (: :)
					c:copy/c:id_movie'
					PASSING v_xmltype RETURNING CONTENT
				)
				AS INTEGER
			) INTO v_idMovie
			FROM dual;
			
			UPDATE movie_xml 
			SET OBJECT_VALUE  =
			XMLQuery
			(
				('declare default element namespace "http://www.rennequinpolis.be/movie.xsd"; (: :)
				declare namespace m = "http://www.rennequinpolis.be/movie.xsd"; (: :)
				copy $tmp := . 
				modify
				(
					for $i in $tmp/m:movie[m:id='||v_idMovie||']/m:nb_copies/text()
						return replace value of node $i
						with xs:int($i + 1)
				) 
				return $tmp')
				PASSING OBJECT_VALUE RETURNING CONTENT
			);
			COMMIT;
		END LOOP;
		
	EXCEPTION
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
			
	END get_ccopy_from_cb;					
	/* END GET_CCOPY_FROM_CB*/
	
END PACK_MANAGECLOB;
/