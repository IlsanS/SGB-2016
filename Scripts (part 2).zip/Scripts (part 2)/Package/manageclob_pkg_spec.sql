-- ###############################
-- # CREATE PACKAGE MANAGECLOB
-- ###############################
CREATE OR REPLACE PACKAGE PACK_MANAGECLOB
IS
	-- To get movie clob on local database
	PROCEDURE get_cmovie_from_cb;
	
	-- To get copy clob on local database
	PROCEDURE get_ccopy_from_cb;
	
END PACK_MANAGECLOB;
/