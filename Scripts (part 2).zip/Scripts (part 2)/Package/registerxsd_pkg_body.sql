-- ###############################
-- # PACKAGE REGISTERXSD BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_REGISTERXSD
IS 
	/* BEGIN REGISTER_XSD */
	PROCEDURE register_xsd
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd';
		
	BEGIN
		PACK_REGISTERXSD.register_xsd_user;
		PACK_REGISTERXSD.register_xsd_movie;
		PACK_REGISTERXSD.register_xsd_certification;
		PACK_REGISTERXSD.register_xsd_artist;
		PACK_REGISTERXSD.register_xsd_copy;
		PACK_REGISTERXSD.register_xsd_cert_movie;
		PACK_REGISTERXSD.register_xsd_direct;
		PACK_REGISTERXSD.register_xsd_errors;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd;					
	/* END REGISTER_XSD*/
	
	/* BEGIN REGISTER_XSD_USER */
	PROCEDURE register_xsd_user
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_USER';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_utilisateur';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/user.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/user.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_user;					
	/* END REGISTER_XSD_USER*/
	
	/* BEGIN REGISTER_XSD_MOVIE */
	PROCEDURE register_xsd_movie
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_MOVIE';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_film';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/movie.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/movie.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_movie;					
	/* END REGISTER_XSD_MOVIE*/
	
	/* BEGIN REGISTER_XSD_CERTIFICATION */
	PROCEDURE register_xsd_certification
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_CERTFICATION';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_certification';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/certification.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/certification.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_certification;					
	/* END REGISTER_XSD_CERTIFICATION*/
	
	/* BEGIN REGISTER_XSD_ARTIST */
	PROCEDURE register_xsd_artist
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_ARTIST';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_artiste';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/artist.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/artist.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_artist;					
	/* END REGISTER_XSD_ARTIST*/
	
	/* BEGIN REGISTER_XSD_COPY */
	PROCEDURE register_xsd_copy
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_COPY';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_copie';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/copy.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/copy.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_copy;					
	/* END REGISTER_XSD_COPY*/
	
	/* BEGIN REGISTER_XSD_CERT_MOVIE */
	PROCEDURE register_xsd_cert_movie
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_CERT_MOVIE ';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_certification_film';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/cert_movie.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/cert_movie.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_cert_movie;					
	/* END REGISTER_XSD_CERT_MOVIE*/
	
	/* BEGIN REGISTER_XSD_DIRECT */
	PROCEDURE register_xsd_direct
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_DIRECT';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_réalise';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/direct.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/direct.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_direct;					
	/* END REGISTER_XSD_DIRECT*/
	
	/* BEGIN REGISTER_XSD_ERRORS */
	PROCEDURE register_xsd_errors
	IS
		-- Location of the error
		c_loca		CONSTANT VARCHAR(200) := 'PACK_REGISTERXSD.PROC_REGISTER_XSD_ERRORS';
		-- Type of the error
		c_type_err	CONSTANT VARCHAR(1000) := 'erreur_enregistrement_xsd_erreurs';
		
	BEGIN
		DBMS_XMLSCHEMA.registerschema
		(
			schemaurl	=> 	'http://www.rennequinpolis.be/logging_errors.xsd',
			schemadoc	=> 	BFILENAME('SRC_DIR', 'schemas/logging_errors.xsd'),
			local		=> 	TRUE,
			gentypes	=> 	TRUE,
			gentables	=> 	FALSE,
			csid		=> 	NLS_CHARSET_ID('AL32UTF8')
		);
		COMMIT;
		
	EXCEPTION 
		WHEN OTHERS THEN 
			PACK_ERROR.report_and_go(c_loca, PACK_ERROR.c_xdb, c_type_err, TRUE);
		
	END register_xsd_errors;					
	/* END REGISTER_XSD_ERRORS*/
	
END PACK_REGISTERXSD ;
/