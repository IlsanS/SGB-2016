-- ###############################
-- # CREATE PACKAGE REGISTERXSD
-- ###############################
CREATE OR REPLACE PACKAGE PACK_REGISTERXSD 
IS
	-- Register all the schemas
	PROCEDURE register_xsd;
	
	-- Register schema of table user_movie_xml
	PROCEDURE register_xsd_user;
	
	-- Register schema of table movie_xml
	PROCEDURE register_xsd_movie;
	
	-- Register schema of table certification_xml
	PROCEDURE register_xsd_certification;
	
	-- Register schema of table artist_xml
	PROCEDURE register_xsd_artist;
	
	-- Register schema of table copy_xml
	PROCEDURE register_xsd_copy;
	
	-- Register schema of table cert_movie_xml
	PROCEDURE register_xsd_cert_movie;
	
	-- Register schema of table direct_xml
	PROCEDURE register_xsd_direct;
	
	-- Register schema of table logging_errors
	PROCEDURE register_xsd_errors;
	
END PACK_REGISTERXSD;
/	
	