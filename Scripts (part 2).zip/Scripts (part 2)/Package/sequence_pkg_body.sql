-- ###############################
-- # PACKAGE SEQUENCE BODY
-- ###############################
CREATE OR REPLACE PACKAGE BODY PACK_SEQUENCE 
IS 
	
	/* DEBUT getIdUser */
	FUNCTION getIdUser RETURN NUMBER
	IS
		v_result 			NUMBER := 0;
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_SEQUENCE.FUNC_GETIDUSER';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'sequence_getIdUser';
		
	BEGIN
		--On CBB
		--v_result := seqUser_cb.NEXTVAL;
		--On CB
		v_result := seqUser.NEXTVAL;
		RETURN v_result;
		
	EXCEPTION
		WHEN OTHERS THEN 
			--ROLLBACK;
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_seq, c_type_err, true);
	
	END getIdUser;
	-- /* FIN getIdUser*/
	
	/* DEBUT getIdErr */
	FUNCTION getIdErr RETURN NUMBER
	IS
		v_result 			NUMBER := 0;
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_SEQUENCE.FUNC_GETIDERR';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'sequence_getIdErr';
		
	BEGIN
		v_result := seqErr.NEXTVAL;
		RETURN v_result;
		
	EXCEPTION
		WHEN OTHERS THEN 
			--ROLLBACK;
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_seq, c_type_err, true);
			
	END getIdErr;
	-- /* getIdErr*/
	
	/* DEBUT getIdState */
	FUNCTION getIdState RETURN NUMBER
	IS
		v_result 			NUMBER := 0;
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PACK_SEQUENCE.FUNC_GETIDSTATE';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'sequence_getIdState';
		
	BEGIN
		v_result := seqState.NEXTVAL;
		RETURN v_result;
		
	EXCEPTION
		WHEN OTHERS THEN 
			--ROLLBACK;
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_seq, c_type_err, true);
			
	END getIdState;
	-- /* getIdState*/
	
	
END PACK_SEQUENCE;
/