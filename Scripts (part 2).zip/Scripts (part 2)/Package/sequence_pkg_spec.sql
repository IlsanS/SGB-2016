-- ###############################
-- # CREATE PACKAGE SEQUENCE
-- ###############################
CREATE OR REPLACE PACKAGE PACK_SEQUENCE 
IS 

	FUNCTION getIdUser RETURN NUMBER;
	
	FUNCTION getIdErr RETURN NUMBER;
	
	FUNCTION getIdState RETURN NUMBER;
	
	
END PACK_SEQUENCE;
/