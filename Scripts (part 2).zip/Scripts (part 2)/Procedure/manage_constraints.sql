	
	/* Procedure to enable/disable constraints */
	CREATE OR REPLACE PROCEDURE manage_constraints 
	(	
		p_status IN VARCHAR2
	)
	IS
		CURSOR const_cur
		IS
			SELECT constraint_name, table_name, status
			FROM user_constraints
			WHERE constraint_type in ('R') 
			AND 
			(	
				constraint_name like 'FK%'
			); 
			-- WHERE constraint_type in ( 'R', 'U','P','C') 
			-- AND 
			-- (	
				-- constraint_name like 'UN%' 
				-- or  constraint_name like 'FK%'
				-- or  constraint_name like 'NN%'
				-- or  constraint_name like 'PK%'
			-- ); 
		v_status		VARCHAR2 (10);
		v_instr_sql     VARCHAR2 (300);
		-- Location of the error
		c_loca		CONSTANT LOGGING_ERRORS.location%TYPE := 'PROC_MANAGE_CONSTRAINTS';
		-- Type of the error
		c_type_err	CONSTANT LOGGING_ERRORS.message%TYPE := 'erreur_enable_disable_contraintes';

	BEGIN
		FOR const IN const_cur
			LOOP
				v_instr_sql   := 'ALTER TABLE '
								|| const.table_name
								|| ' '
								|| p_status
								|| '  CONSTRAINT '
								|| const.constraint_name;
				EXECUTE IMMEDIATE v_instr_sql;
			END LOOP;
			
	EXCEPTION
		WHEN OTHERS THEN
			PACK_ERROR.report_and_stop(c_loca, PACK_ERROR.c_util, c_type_err, TRUE);
	END;