-- ###############################
-- # SEQUENCE : USERS
-- ###############################

CREATE SEQUENCE seqUser
	INCREMENT BY 1
	START WITH 1
	MAXVALUE 10000;
	
-- ###############################
-- # SEQUENCE : ERRORS
-- ###############################

CREATE SEQUENCE seqErr
	INCREMENT BY 1
	START WITH 1
	MAXVALUE 100000;
	
-- ###############################
-- # SEQUENCE : STATES
-- ###############################

CREATE SEQUENCE seqState
	INCREMENT BY 1
	START WITH 1
	MAXVALUE 100000;
	
COMMIT;