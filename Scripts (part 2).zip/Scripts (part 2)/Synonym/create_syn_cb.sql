-- ###############################
-- # SYNONYMS FOR MOVIE
-- ###############################
CREATE OR REPLACE SYNONYM movie_cc 
FOR movie_xml@db_cc@renequinpolis;

-- ###############################
-- # SYNONYMS FOR COPY
-- ###############################
CREATE OR REPLACE SYNONYM copy_cc
FOR copy_xml@db_cc@renequinpolis;