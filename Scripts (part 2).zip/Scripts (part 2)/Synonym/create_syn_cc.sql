-- ###############################
-- # SYNONYMS FOR MOVIE
-- ###############################
CREATE OR REPLACE SYNONYM movie_cb 
FOR movie@db_cb@renequinpolis;

-- ###############################
-- # SYNONYMS FOR COPY
-- ###############################
CREATE OR REPLACE SYNONYM copy_cb
FOR copy@db_cb@renequinpolis;