-- ###############################
-- # CREATE TABLE LOGGING_ERRORS		 
-- ###############################
CREATE TABLE logging_errors
(
	id_log			INTEGER,
	inserted_at 	DATE,
	username		VARCHAR(100),
	code			VARCHAR2(50),	
	location	 	VARCHAR2(200),	
	message			VARCHAR2(1000),	
	sys_message		VARCHAR2(1000),	
	backtrace_msg	VARCHAR2(1000)
)
/

-- ###############################
-- # CREATE TABLE MY_CONSTRAINTS		 
-- ###############################
CREATE TABLE my_constraints
(
	constraint_name	VARCHAR2(100),
	message			VARCHAR2(512),
	CONSTRAINT  pk_nameConstraint	PRIMARY KEY(constraint_name)
)
/	

COMMIT;