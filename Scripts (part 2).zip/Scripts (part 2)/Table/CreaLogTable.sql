-- ###############################
-- # CREATE TABLE LOGGING_STATES		 
-- ###############################
CREATE TABLE logging_states
(
	id_log			NUMBER(5),
	code			NUMBER(6),
	location		VARCHAR2(100),
	message			VARCHAR2(300),
	other_infos		VARCHAR2(150),
	inserted_at 	DATE
)
/	

COMMIT;