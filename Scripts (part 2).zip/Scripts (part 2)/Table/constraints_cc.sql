----------------------------------------------------
-- TOTAL VALIDATION WITH OBJECT RELATIONAL STORAGE
----------------------------------------------------
ALTER TABLE user_movie_xml
ADD CONSTRAINT valid_user_movie
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

ALTER TABLE movie_xml
ADD CONSTRAINT valid_movie
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

ALTER TABLE certification_xml
ADD CONSTRAINT valid_certification
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

ALTER TABLE artist_xml
ADD CONSTRAINT valid_artist
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

ALTER TABLE copy_xml
ADD CONSTRAINT valid_copy
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

ALTER TABLE cert_movie_xml
ADD CONSTRAINT valid_cert_movie
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

ALTER TABLE direct_xml
ADD CONSTRAINT valid_direct
CHECK (XMLIsValid(OBJECT_VALUE) = 1);

----------------------------------------------------
-- PRIMARY KEY CONSTRAINTS
----------------------------------------------------
ALTER TABLE user_movie_xml
ADD CONSTRAINT pk_idUser
	PRIMARY KEY(XMLDATA."ID_USER");
	
ALTER TABLE movie_xml
ADD CONSTRAINT pk_idMovie
	PRIMARY KEY(XMLDATA."ID");

ALTER TABLE certification_xml
ADD CONSTRAINT pk_cert
	PRIMARY KEY(XMLDATA."ID");
	
ALTER TABLE artist_xml
ADD CONSTRAINT pk_artist
	PRIMARY KEY(XMLDATA."ID");
	
ALTER TABLE copy_xml
ADD CONSTRAINT pk_copy
	PRIMARY KEY(XMLDATA."NUM", XMLDATA."ID_MOVIE");
	
ALTER TABLE cert_movie_xml
ADD CONSTRAINT pk_cert_movie
	PRIMARY KEY(XMLDATA."ID_MOVIE", XMLDATA."ID_CERT");
	
ALTER TABLE direct_xml
ADD CONSTRAINT pk_direct
	PRIMARY KEY(XMLDATA."ID_MOVIE", XMLDATA."ID_DIRECTOR");

----------------------------------------------------
-- FOREIGN KEY CONSTRAINTS
----------------------------------------------------
ALTER TABLE copy_xml
ADD CONSTRAINT fk_copy_idMovie_movie	
	FOREIGN KEY(XMLDATA."ID_MOVIE") 
	REFERENCES movie_xml(XMLDATA."ID");
	
ALTER TABLE cert_movie_xml
ADD CONSTRAINT fk_certm_idMovie_movie	
	FOREIGN KEY(XMLDATA."ID_MOVIE") 
	REFERENCES movie_xml(XMLDATA."ID");
	
ALTER TABLE cert_movie_xml
ADD CONSTRAINT fk_certm_idMovie_cert	
	FOREIGN KEY(XMLDATA."ID_CERT") 
	REFERENCES certification_xml(XMLDATA."ID");
	
ALTER TABLE direct_xml
ADD CONSTRAINT fk_dir_idMovie_movie	
	FOREIGN KEY(XMLDATA."ID_MOVIE") 
	REFERENCES movie_xml(XMLDATA."ID");

ALTER TABLE direct_xml
ADD CONSTRAINT fk_dir_idMovie_direct	
	FOREIGN KEY(XMLDATA."ID_DIRECTOR") 
	REFERENCES artist_xml(XMLDATA."ID");	
	
----------------------------------------------------
-- UNIQUE CONSTRAINTS
----------------------------------------------------
ALTER TABLE user_movie_xml
ADD CONSTRAINT un_auth	
	UNIQUE(XMLDATA."LOGIN");	

ALTER TABLE user_movie_xml
ADD CONSTRAINT un_email	
	UNIQUE(XMLDATA."EMAIL");	
	
----------------------------------------------------
-- CHECK CONSTRAINTS
----------------------------------------------------	
ALTER TABLE user_movie_xml
ADD CONSTRAINT ck_crea_upd 
	CHECK(XMLDATA."CREATED_AT" <= XMLDATA."UPDATED_AT");
	
-- NOT NULL verified by xsd 
	
COMMIT;