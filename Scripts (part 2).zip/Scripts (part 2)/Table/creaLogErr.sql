/**********************************************************************
		  			TABLES LOG/ERROR	
***********************************************************************/

CREATE TABLE "LOGS"
( 
	"AT" 			DATE, 
	"MESSAGE" 		VARCHAR2(1000 BYTE)
) ;
/

CREATE TABLE "ERRLOG" 
(
	"CREATED_ON"	DATE, 
	"ERRCODE" 		INT,
	"ERRMSG" 		VARCHAR2(4000 BYTE), 
	"CREATED_BY" 	VARCHAR2(1000 BYTE)
);
/

COMMIT;