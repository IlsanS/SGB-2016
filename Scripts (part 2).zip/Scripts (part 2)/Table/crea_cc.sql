-- ###############################
-- # CREATE TABLE USER
-- ###############################
CREATE TABLE user_movie_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/user.xsd"
ELEMENT	"user";
/

-- -- ###############################
-- -- # CREATE TABLE MOVIE
-- -- ###############################
CREATE TABLE movie_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/movie.xsd"
ELEMENT	"movie";
/

-- -- ###############################
-- -- # CREATE TABLE CERTIFICATION
-- -- ###############################
CREATE TABLE certification_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/certification.xsd"
ELEMENT	"certification";
/

-- ###############################
-- # CREATE TABLE ARTIST
-- ###############################
CREATE TABLE artist_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/artist.xsd"
ELEMENT	"artist";
/

-- ###############################
-- # CREATE TABLE COPY
-- ###############################
CREATE TABLE copy_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/copy.xsd"
ELEMENT	"copy";
/

-- ###############################
-- # CREATE TABLE CERT_MOVIE
-- ###############################
CREATE TABLE cert_movie_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/cert_movie.xsd"
ELEMENT	"cert_movie";
/

-- ###############################
-- # CREATE TABLE DIRECT
-- ###############################
CREATE TABLE direct_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/direct.xsd"
ELEMENT	"direct";
/

-- ###############################
-- # CREATE TABLE LOGGING_ERRORS
-- ###############################
CREATE TABLE logging_errors_xml OF XMLTYPE
XMLTYPE STORE AS OBJECT RELATIONAL
XMLSCHEMA "http://www.rennequinpolis.be/logging_errors.xsd"
ELEMENT	"logging_errors";
/
COMMIT;