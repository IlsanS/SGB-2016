---------------------
-- To do on cb
---------------------
CREATE TABLE remote_movie
(	
	p_clob 	CLOB
);
/

CREATE TABLE remote_copy
(	
	p_clob 	CLOB
);
/

-- For example
INSERT INTO REMOTE_MOVIE VALUES(PACK_GENXMLFROMSQL.gen_xml_movie(12).getClobVal());
INSERT INTO REMOTE_MOVIE VALUES(PACK_GENXMLFROMSQL.gen_xml_movie(14).getClobVal());
INSERT INTO REMOTE_COPY VALUES(PACK_GENXMLFROMSQL.gen_xml_copy(1,12).getClobVal());
INSERT INTO REMOTE_COPY VALUES(PACK_GENXMLFROMSQL.gen_xml_copy(2,14).getClobVal());
COMMIT;

---------------------
-- To do on cc
---------------------
-- Temporary tables
CREATE GLOBAL TEMPORARY TABLE gtt_movie
ON COMMIT PRESERVE ROWS AS SELECT p_clob 
FROM REMOTE_MOVIE@db_cb@renequinpolis;
/

CREATE GLOBAL TEMPORARY TABLE gtt_copy
ON COMMIT PRESERVE ROWS AS SELECT p_clob 
FROM REMOTE_COPY@db_cb@renequinpolis;
/

-- Before insert : no rows
SELECT * FROM gtt_movie;
SELECT * FROM gtt_copy;

-- To get the structure of the tables
DESC gtt_movie;
DESC gtt_copy;

-- For example
INSERT INTO gtt_movie SELECT p_clob FROM REMOTE_MOVIE@db_cb@renequinpolis;
INSERT INTO gtt_copy SELECT p_clob FROM REMOTE_COPY@db_cb@renequinpolis;

-- Create procedure 
get_clob_from_cb



