	
	-- Execute on CB
	--Exécuter alim_copy_cb.sql dans Utils
	DELETE FROM gtt_movie@db_cc@renequinpolis;
	DELETE FROM gtt_copy@db_cc@renequinpolis;
	EXEC PACK_ALIMCC.alimcc_by_xml;
	