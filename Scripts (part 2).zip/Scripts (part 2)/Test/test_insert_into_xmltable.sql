
INSERT INTO copy_xml VALUES
(
	XMLType
    (
		xmlData   => BFILENAME('SRC_DIR','docxml/copy1_2.xml'),
		csid      => NLS_CHARSET_ID('AL32UTF8')
	)
);