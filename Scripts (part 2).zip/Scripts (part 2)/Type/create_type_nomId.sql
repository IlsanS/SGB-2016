/*******************************************************
             CREATE OBJECT + COMPARATOR
*********************************************************/
CREATE OR REPLACE TYPE nomId AS OBJECT (
	nom    VARCHAR(1000),
	id     NUMBER,
ORDER MEMBER FUNCTION SORT (P nomId) RETURN INTEGER );

/

CREATE OR REPLACE TYPE BODY nomId AS
ORDER MEMBER FUNCTION SORT(P nomId) RETURN INTEGER IS
BEGIN

   IF id < P.id THEN
      RETURN -1;
   ELSIF id > P.id THEN
      RETURN 1;
   ELSE
      RETURN 0;
   END IF;
END;
END;

/*********************************************************
             CREATE TABLE OF OBJECTS (id, varchar)
*********************************************************/
CREATE OR REPLACE TYPE nomId_tab AS TABLE OF nomId;


/*********************************************************
             CREATE TABLE OF OBJECTS (varchar)
*********************************************************/
CREATE OR REPLACE TYPE varchar_tab_type AS TABLE OF varchar2(3000);