-- ###############################
-- # TO EMPTY ALL THE TABLES
-- ###############################
DELETE FROM user_movie;
DELETE FROM movie; 
DELETE FROM overview;
DELETE FROM certification; 
DELETE FROM artist;
DELETE FROM genre; 
DELETE FROM status;
DELETE FROM copy; 
DELETE FROM cert_movie;
DELETE FROM play; 
DELETE FROM direct;
DELETE FROM genre_movie; 
DELETE FROM status_movie;
DELETE FROM logging_errors;
DELETE FROM logging_states;

DELETE FROM remote_movie;
DELETE FROM remote_copy;


DELETE FROM user_movie;
DELETE FROM movie; 
DELETE FROM overview;
DELETE FROM artist;
DELETE FROM genre; 
DELETE FROM play; 
DELETE FROM direct;
DELETE FROM genre_movie;


DELETE FROM copy_xml; 
DELETE FROM cert_movie_xml; 
DELETE FROM direct_xml;
DELETE FROM user_movie_xml;
DELETE FROM movie_xml; 
DELETE FROM certification_xml;
DELETE FROM artist_xml;
DELETE FROM logging_errors_xml;
DELETE FROM gtt_movie;
DELETE FROM gtt_copy;