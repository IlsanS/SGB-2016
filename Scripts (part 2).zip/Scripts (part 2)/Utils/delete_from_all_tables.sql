-- ###############################
-- # TO EMPTY ALL THE TABLES
-- ###############################
DELETE FROM user_movie;
DELETE FROM movie; 
DELETE FROM overview;
DELETE FROM certification; 
DELETE FROM artist;
DELETE FROM genre; 
DELETE FROM status;
DELETE FROM copy; 
DELETE FROM cert_movie;
DELETE FROM play; 
DELETE FROM direct;
DELETE FROM genre_movie; 
DELETE FROM status_movie;