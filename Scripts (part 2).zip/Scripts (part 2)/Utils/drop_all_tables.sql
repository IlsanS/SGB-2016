-- ###############################
-- # TO DROP ALL THE TABLES
-- ###############################
DROP TABLE copy; 
DROP TABLE cert_movie;
DROP TABLE play; 
DROP TABLE direct;
DROP TABLE genre_movie; 
DROP TABLE status_movie; 
DROP TABLE overview;
DROP TABLE certification; 
DROP TABLE artist;
DROP TABLE genre; 
DROP TABLE status;
DROP TABLE user_movie;
DROP TABLE movie;
DROP TABLE logging_errors;
DROP TABLE logging_states;
DROP TABLE my_constraints;


DROP TABLE cert_movie_xml;
DROP TABLE copy_xml;
DROP TABLE direct_xml;
DROP TABLE artist_xml;
DROP TABLE movie_xml;
DROP TABLE user_movie_xml;
DROP TABLE certification_xml;