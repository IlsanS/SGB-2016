
-- To get statistic informations with autotrace (as sys)

create role plustrace;
grant select on v_$sesstat to plustrace;
grant select on v_$statname to plustrace;
grant select on v_$mystat to plustrace;
grant plustrace to dba with admin option;
set echo off;
grant plustrace to cb;
