-- ###############################
-- # CREATE VIEW USER
-- ###############################
CREATE OR REPLACE VIEW user_movie_view AS
SELECT us.* 
FROM user_movie_xml uxml, 
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/user.xsd' AS "u"), 
	'/u:user' PASSING uxml.OBJECT_VALUE 
	COLUMNS		
		id_user			NUMBER(5)		PATH'u:id_user',
		lastname 		VARCHAR2(40)	PATH'u:lastname',
		firstname		VARCHAR2(60)	PATH'u:firstname',	
		login			VARCHAR2(30)	PATH'u:login',
		pwd				VARCHAR2(30)	PATH'u:pwd',
		sex				CHAR(1)			PATH'u:sex',
		email			VARCHAR2(80)	PATH'u:email',
		birthday		DATE			PATH'u:birthday',
		created_at		DATE			PATH'u:created_at',
		updated_at		DATE			PATH'u:updated_at',	
		address			VARCHAR2(100)	PATH'u:address',
		is_deleted		CHAR(1) 		PATH'u:is_deleted',
		deleted_at		DATE			PATH'u:deleted_at',
		token			VARCHAR(30) 	PATH'u:token'
	
)us;
/

-- -- ###############################
-- -- # CREATE VIEW MOVIE
-- -- ###############################
CREATE OR REPLACE VIEW movie_view AS
SELECT mo.* 
FROM movie_xml mxml, 
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/movie.xsd' AS "m"), 
	'/m:movie' PASSING mxml.OBJECT_VALUE 
	COLUMNS	
		id 				INTEGER 		PATH'm:id',
		title 			VARCHAR2(100)	PATH'm:title',
		poster 			BLOB			PATH'm:poster',
		nb_copies 		INT				PATH'm:nb_copies'
)mo;
/

-- -- ###############################
-- -- # CREATE VIEW CERTIFICATION
-- -- ###############################
CREATE OR REPLACE VIEW certification_view AS
SELECT ce.*
FROM certification_xml cxml,
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/certification.xsd' AS "c"),
	'/c:certification' PASSING cxml.OBJECT_VALUE 
	COLUMNS	
		id 				VARCHAR(6)			PATH'c:id',
		name 			VARCHAR(50)			PATH'c:name',
		description		VARCHAR2(500)		PATH'c:description'
)ce;
/

-- ###############################
-- # CREATE VIEW ARTIST
-- ###############################
CREATE OR REPLACE VIEW artist_view AS
SELECT ar.*
FROM artist_xml axml,
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/artist.xsd' AS "a"),
	'a:artist' PASSING axml.OBJECT_VALUE
	COLUMNS	
		id 				VARCHAR(7)			PATH'a:id',
		name 			VARCHAR(30)			PATH'a:name'
)ar;
/

-- ###############################
-- # CREATE VIEW COPY
-- ###############################
CREATE OR REPLACE VIEW copy_view AS
SELECT cp.*
FROM copy_xml coxml,
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/copy.xsd' AS "co"),
	'co:copy' PASSING coxml.OBJECT_VALUE
	COLUMNS	
		num				INTEGER				PATH'co:num',
		id_movie 		INTEGER				PATH'co:id_movie'
)cp;
/

-- ###############################
-- # CREATE VIEW CERT_MOVIE
-- ###############################
CREATE OR REPLACE VIEW cert_movie_view AS
SELECT ct.*
FROM cert_movie_xml cmxml,
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/cert_movie.xsd' AS "cm"),
	'cm:cert_movie' PASSING cmxml.OBJECT_VALUE
	COLUMNS
		id_movie		INTEGER				PATH'cm:id_movie',
		id_cert			VARCHAR(5)			PATH'cm:id_cert'	
)ct;
/

-- ###############################
-- # CREATE VIEW DIRECT
-- ###############################
CREATE OR REPLACE VIEW direct_view AS
SELECT di.*
FROM direct_xml dxml,
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/direct.xsd' AS "d"),
	'd:direct' PASSING dxml.OBJECT_VALUE
	COLUMNS
		id_movie		INTEGER				PATH'd:id_movie',
		id_director		NUMBER(7)			PATH'd:id_director'	
)di;
/

-- ###############################
-- # CREATE VIEW LOGGING_ERRORS
-- ###############################
CREATE OR REPLACE VIEW logging_errors_view AS
SELECT er.*
FROM logging_errors_xml exml,
XMLTABLE
(
	XMLNamespaces('http://www.rennequinpolis.be/logging_errors.xsd' AS "e"),
	'e:logging_errors' PASSING exml.OBJECT_VALUE
	COLUMNS
		id_log			INTEGER				PATH'e:id_log',
		inserted_at 	DATE				PATH'e:inserted_at',
		username		VARCHAR2(100)		PATH'e:username',
		code			VARCHAR2(50)		PATH'e:code',	
		location	 	VARCHAR2(200)		PATH'e:location',	
		message			VARCHAR2(1000)		PATH'e:message',	
		sys_message		VARCHAR2(1000)		PATH'e:sys_message',	
		backtrace_msg	VARCHAR2(1000)		PATH'e:backtrace_msg'
)er;
/

COMMIT;